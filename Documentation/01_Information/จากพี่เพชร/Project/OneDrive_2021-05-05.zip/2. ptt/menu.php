<html>
<head> 
<style> 
	body {background: lightblue;} 
</style> 
</head>
<body>
<div style="position:relative; top:50px;">
<h1>Menu</h1>
<ul>
<li> <a href="index.php?id=basic_data_jexcel" target="_parent">Basic Data</a></li>
<li> <a href="index.php?id=ethane" target="_parent">Ethane</a></li>
<li> <a href="index.php?id=ngl" target="_parent">NGL</a></li>
<li> <a href="index.php?id=propane_lpg" target="_parent">Propane&LPG</a></li>
<li> <a href="index.php?id=summary" target="_parent">Summary</a></li>
</ul>
</div>
</body>
</html>
