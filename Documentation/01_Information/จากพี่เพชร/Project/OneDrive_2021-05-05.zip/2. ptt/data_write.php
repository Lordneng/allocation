<html>
<body>
<?php 	 
/*
	$yy = $_POST["yy"];
	$pCost = $_POST["pCost"];
	$rPrice = $_POST["rPrice"];
	$estVol = $_POST["estVol"];
	$maxLim = $_POST["maxLim"];
	$pttExc = $_POST["pttExc"];
	$cusName = $_POST["cusName"];
	$cusExc = $_POST["cusExc"];
	$cusEth = $_POST["cusEth"];
	$cusEthData = $_POST["cusEthData"];
	//$file = fopen("test.js","w");
	//echo fwrite($file,"Hello World. Testing!");
	//fclose($file);
*/

	$myfile = fopen("basic_data.dat", "w") or die("Unable to open file!");

	foreach($_POST as $key => $value) {
//	    echo $key . "=" . $value . '<br><br>';
	    fwrite($myfile,$key."=".$value.";\n\n");
	}

	fclose($myfile);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
</body></html>
