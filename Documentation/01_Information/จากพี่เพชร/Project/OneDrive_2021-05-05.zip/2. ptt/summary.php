<!DOCTYPE html>
<html>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
}
th { color: white; font-size:10pt;}
</style>

<style>
@media print {
    body {-webkit-print-color-adjust: exact;}
    @page {size: A4 ;max-height:100%; max-width:100%}
    table {page-break-inside: avoid;}
}
</style>

<body>
<script src="glpk.min.js"></script>
<?php
echo "<script>";
//<script src="basic_data.js"></script>
echo file_get_contents('./basic_data.dat', FILE_USE_INCLUDE_PATH);
echo "</script>";
?>
<script src="conv_data.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<script src="numeral.min.js"></script>

<div style="position:relative; top:50px;">

<div align=center><h1>Summary</h1></div>

<button onclick="myFunction()">Print this page</button><br><br>

<script>
function myFunction() {
  window.print();
}
</script>

<font size=2>

<font size=4><b>Product Revenue and Margin (1 Year):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodRev1y_table></div><br><br>
</div>

<font size=4><b>Product Revenue by Month (THB):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodRevBM_table></div><br><br>
</div>

<font size=4><b>Product Cost by Month (THB):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodCostBM_table></div><br><br>
</div>

<font size=4><b>Product Margin by Month (THB):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodMargBM_table></div><br><br>
</div>

<font size=4><b>12 Month Plan - Customer:</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=planCus12M_table></div><br><br>
</div>

<font size=4><b>12 Month Plan - Technical:</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=planTec12M_table></div><br><br>
</div>

<p style="page-break-before: always">
<!--
<font size=4><b>12 Month Revenue (THB):</b></font><br><br>
<div id=prodRev12M_table></div><br><br>

<font size=4><b>12 Month Produciton Cost (THB):</b></font><br><br>
<div id=prodCost12M_table></div><br><br>

<font size=4><b>12 Month Margin (THB):</b></font><br><br>
<div id=prodMarg12M_table></div><br><br>
-->
<font size=4><b>12 Month Revenue (THB):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodRev12M_table_new></div><br><br>
</div>

<font size=4><b>12 Month Production Cost (THB):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodCost12M_table_new></div><br><br>
</div>

<font size=4><b>12 Month Margin (THB):</b></font><br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=prodMarg12M_table_new></div><br><br>
</div>
</font>

</div>

<script>
den_tpm3=1;//0.648;
function create_prodRev1y_table(ccname){
	tdata=[];
	for (k=0;k<6;++k){
	trev=0;tpdc=0;tmarg=0;
	tname = "";
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG";}
	if(k==4){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==5){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
	if(k!=3){
		for (j=0;j<12;++j){
			for (i=0;i<cname.length;++i){
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];
				trev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			}
			tpdc+=1000*estVol[id_pc][j+2]*pCost[id_pc][j+2]*pttExc[0][j+2]*den_tpm3;
		}
	}
	tmarg += trev-tpdc;
	tdata.push([tname,trev,tpdc,tmarg]);
	}

	tdata[3][1] = tdata[4][1]+tdata[5][1];
	tdata[3][2] = tdata[4][2]+tdata[5][2];
	tdata[3][3] = tdata[4][3]+tdata[5][3];

	tt=["Total"];
	for(i=0;i<3;++i){
		tt1 = 0;
		for(k=0;k<6;++k){
		if(k!=3){	
			tt1+=tdata[k][i+1];
		}
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodRev1y  border=1><tr bgcolor=mediumblue><th>Product</th><th>Revenue(THB)</th><th>Product Cost(THB)</th><th>Margin</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i<4||i==6){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i<4||i==6){
				html += "<td align=right width=120><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=120>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodRev1y_table").innerHTML = html;
}


function create_prodRevBM_table(ccname){
	tdata=[];
	for (k=0;k<6;++k){
	trev=0;tpdc=0;tmarg=0;
	tname = ""; trev_m=[];
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG";}
	if(k==4){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==5){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
	if(k!=3){
		for (j=0;j<12;++j){
			ttrev = 0;
			for (i=0;i<cname.length;++i){
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];				
				ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			}
			trev += ttrev;
			trev_m.push(ttrev);
//			tpdc+=1000*estVol[id_pc][j+2]*pCost[id_pc][j+2]*pttExc[0][j+2]*den_tpm3;
		}
	}
//	tmarg += trev-tpdc;
	tdata.push([tname].concat(trev_m).concat([trev]));
//	console.log(tdata);
	}

	for(i=1;i<14;++i){
		tdata[3][i] = tdata[4][i]+tdata[5][i];
	}

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<6;++k){
		if(k!=3){	
			tt1+=tdata[k][i+1];
		}
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodRevBM  border=1><tr bgcolor=mediumblue><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i<4 || i==6){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i<4 || i==6){
				html += "<td align=right width=90><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=90>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodRevBM_table").innerHTML = html;
}


function create_prodCostBM_table(ccname){
	tdata=[];
	for (k=0;k<6;++k){
	trev=0;tpdc=0;tmarg=0;
	tname = ""; tpdc_m=[];
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG";}
	if(k==4){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==5){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
	if(k!=3){
		for (j=0;j<12;++j){
			ttrev = 0;
/*
			for (i=0;i<cname.length;++i){
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];				
				ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			}
*/
//			tpdc+=1000*estVol[id_pc][j+2]*pCost[id_pc][j+2]*pttExc[0][j+2]*den_tpm3;
			ttpdc =1000*estVol[id_pc][j+2]*pCost[id_pc][j+2]*pttExc[0][j+2]*den_tpm3;
			tpdc += ttpdc;
			tpdc_m.push(ttpdc);
//			console.log(tpdc_m);
		}
	}
//	tmarg += trev-tpdc;
	tdata.push([tname].concat(tpdc_m).concat([tpdc]));
//	console.log(tdata);
	}

	for(i=1;i<14;++i){
		tdata[3][i] = tdata[4][i]+tdata[5][i];
	}

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<6;++k){
		if(k!=3){	
			tt1+=tdata[k][i+1];
		}
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodCostBM  border=1><tr bgcolor=mediumblue><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i<4 || i==6){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i<4 || i==6){
				html += "<td align=right width=90><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=90>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodCostBM_table").innerHTML = html;
}

function create_prodMargBM_table(ccname){
	tdata=[];
	for (k=0;k<6;++k){
	trev=0;tpdc=0;tmarg=0;
	tname = ""; tmarg_m=[];
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG";}
	if(k==4){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==5){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
	if(k!=3){
		for (j=0;j<12;++j){
			ttrev = 0;
			for (i=0;i<cname.length;++i){
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];				
				ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			}
			trev += ttrev;
			ttpdc =1000*estVol[id_pc][j+2]*pCost[id_pc][j+2]*pttExc[0][j+2]*den_tpm3;
			tpdc += ttpdc;
			tmarg_m.push(ttrev-ttpdc);
		}
	}
	tmarg += trev-tpdc;
	tdata.push([tname].concat(tmarg_m).concat([tmarg]));
	}

	for(i=1;i<14;++i){
		tdata[3][i] = tdata[4][i]+tdata[5][i];
	}

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<6;++k){
		if(k!=3){	
			tt1+=tdata[k][i+1];
		}
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodMargBM  border=1><tr bgcolor=mediumblue><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i<4|| i==6){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i<4 || i==6){
				html += "<td align=right width=90><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=90>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodMargBM_table").innerHTML = html;
}

function create_prodRev12M_table(ccname){
	tdata=[];
	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	trev=0;tpdc=0;tmarg=0;
	trev_m=[];tpdc_m=[];tmarg_m=[];

	for (j=0;j<12;++j){
	ttrev = 0;ttpdc=0;

	for (k=0;k<5;++k){
	tname = ""; 
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
		
	for (i=0;i<cname.length;++i){
		if(ttname==cname[i]){
//			console.log(ttname,cname[i]);
			vname = cus_name(kk,i,j);
			pp = ccPrice[cname[i]];				
			ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			ttpdc+=LP_result[vname]*pCost[id_pc][j+2]*cusExc[cname[i]][j+2]; 
		}
	}
	}

	trev += ttrev;
	tpdc += ttpdc;		
	tmarg += ttrev-ttpdc;
	trev_m.push(ttrev)
	tmarg_m.push(ttrev-ttpdc);
	}

	tdata.push([cusExc[ttname][0]].concat(trev_m).concat([trev]));
	}

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<cusName.length;++k){
			tt1+=tdata[k][i+1];
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodRev12M  border=1><tr bgcolor=mediumblue><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i==cusName.length){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i==cusName.length){
				html += "<td align=right width=80><b>" + numeral(tdata[i][j]).format('0,0.00') + "</b></td>";
			} else {
				html += "<td align=right width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodRev12M_table").innerHTML = html;
}

function create_prodCost12M_table(ccname){
	tdata=[];
	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	trev=0;tpdc=0;tmarg=0;
	trev_m=[];tpdc_m=[];tmarg_m=[];

	for (j=0;j<12;++j){
	ttrev = 0;ttpdc=0;

	for (k=0;k<5;++k){
	tname = ""; 
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
		
	for (i=0;i<cname.length;++i){
		if(ttname==cname[i]){
//			console.log(ttname,cname[i]);
			vname = cus_name(kk,i,j);
			pp = ccPrice[cname[i]];				
			ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			ttpdc+=LP_result[vname]*pCost[id_pc][j+2]*cusExc[cname[i]][j+2]; 
		}
	}
	}

	trev += ttrev;
	tpdc += ttpdc;		
	tmarg += ttrev-ttpdc;
	trev_m.push(ttrev)
	tpdc_m.push(ttpdc);
	tmarg_m.push(ttrev-ttpdc);
	}

//	tdata.push([ttname].concat(trev_m).concat([trev]));
	tdata.push([cusExc[ttname][0]].concat(tpdc_m).concat([tpdc]));
	}

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<cusName.length;++k){
			tt1+=tdata[k][i+1];
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodCost12M  border=1><tr bgcolor=mediumblue><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i==cusName.length){
				html += "<td><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i==cusName.length){
				html += "<td align=right><b>" + numeral(tdata[i][j]).format('0,0.00') + "</b></td>";
			} else {
				html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodCost12M_table").innerHTML = html;
}

function create_prodMarg12M_table(ccname){
	tdata=[];
	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	trev=0;tpdc=0;tmarg=0;
	trev_m=[];tpdc_m=[];tmarg_m=[];

	for (j=0;j<12;++j){
	ttrev = 0;ttpdc=0;

	for (k=0;k<5;++k){
	tname = ""; 
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
		
	for (i=0;i<cname.length;++i){
		if(ttname==cname[i]){
//			console.log(ttname,cname[i]);
			vname = cus_name(kk,i,j);
			pp = ccPrice[cname[i]];				
			ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
			ttpdc+=LP_result[vname]*pCost[id_pc][j+2]*cusExc[cname[i]][j+2]; 
		}
	}
	}

	trev += ttrev;
	tpdc += ttpdc;		
	tmarg += ttrev-ttpdc;
	trev_m.push(ttrev)
	tpdc_m.push(ttpdc);
	tmarg_m.push(ttrev-ttpdc);
	}

//	tdata.push([ttname].concat(trev_m).concat([trev]));
//	tdata.push([ttname].concat(tpdc_m).concat([tpdc]));
	tdata.push([cusExc[ttname][0]].concat(tmarg_m).concat([tmarg]));

	}

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<cusName.length;++k){
			tt1+=tdata[k][i+1];
		}
		tt.push(tt1);
	}
	tdata.push(tt);


	var html="<table id=prodMarg12M  border=1><tr bgcolor=mediumblue><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1){
			if(i==cusName.length){
				html += "<td><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i==cusName.length){
				html += "<td align=right><b>" + numeral(tdata[i][j]).format('0,0.00') + "</b></td>";
			} else {
				html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodMarg12M_table").innerHTML = html;
}

function create_planCus12M_table(ccname){
	tdata=[];
	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	first_item=0;

	for (k=0;k<5;++k){
	tname = ""; 
	tpdc_m=[];tpdc=0; 
	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}

	for (j=0;j<12;++j){
	ttpdc=0;
		
	for (i=0;i<cname.length;++i){
		if(ttname==cname[i]){
//			console.log(ttname,cname[i]);
			vname = cus_name(kk,i,j);
			ttpdc+=LP_result[vname]; 
		}
	}

	tpdc_m.push(ttpdc);
	tpdc += ttpdc;
	}

	if(cname.includes(ttname)){
		if(first_item==0){
			tdata.push([cusExc[ttname][0],tname,"Ton"].concat(tpdc_m).concat([tpdc]));
			first_item=1;
		}else{
			tdata.push(["",tname,"Ton"].concat(tpdc_m).concat([tpdc]));
		}		

		if(tname=="NGL"){
			ttngl = ["","","m3"];
			for(ii=0;ii<tpdc_m.length;++ii){
				ttngl.push(tpdc_m[ii]/0.648);
			}
			ttngl.push(tpdc/0.648);
			tdata.push(ttngl);
		}

	}

	}
	}

/*
	tt=["","Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<tdata.length;++k){
			tt1+=tdata[k][i+2];
		}
		tt.push(tt1);
	}
	tdata.push(tt);
*/

	var html="<table id=planCus12M  border=1><tr bgcolor=mediumblue><th>Customer</th><th>Product</th><th>Unit</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3||j==15){
			if(j==0){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			}
			if(j==1||j==2) {
				html += "<td bgcolor=lightblue><b>" + tdata[i][j] + "</td>";
			}
			if(j==15) {
				html += "<td align=right><b>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
			
		} else{
			if(i==tdata.length){
				html += "<td align=right width=80><b>" + numeral(tdata[i][j]).format('0,0.00') + "</b></td>";
			} else {
				html += "<td align=right width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("planCus12M_table").innerHTML = html;
}

function create_planTec12M_table(ccname){
	tdata=[];
	LP_result=LP_result_proLpg;
	ee = [];
	dd = [];
	for (i=0;i<12;++i){
		ee.push(LP_result['e'+(i+1)]);
		dd.push(LP_result['d'+(i+1)]);
	}

	tdata.push(["Propane to LPG transfer","Ton"].concat(dd));
	tdata.push(["LPG-Refinery to LPG transfer","Ton"].concat(ee));

	var html="<table id=planTec12M  border=1><tr bgcolor=mediumblue><th></th><th>Unit</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			if(j<1){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue><b>" + tdata[i][j] + "</td>";
			}
		} else{
			if(i==tdata.length){
				html += "<td align=right width=80><b>" + numeral(tdata[i][j]).format('0,0.00') + "</b></td>";
			} else {
				html += "<td align=right width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("planTec12M_table").innerHTML = html;
}


function create_prodRev12M_table_new(ccname){
	tdata=[];
	t_add_all_m=[];t_add_all=0;
	for(j=0;j<12;++j){
	t_add_all_m.push(0);
	}

	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	t_add_m=[];t_add=0;
	first_item=0;

	for(j=0;j<12;++j){
	t_add_m.push(0);
	}

	for (k=0;k<5;++k){
	tname = ""; 
	trev=0;tpdc=0;tmarg=0;
	trev_m=[];tpdc_m=[];tmarg_m=[];

	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
		

	for (j=0;j<12;++j){
	ttrev = 0;ttpdc=0;

		for (i=0;i<cname.length;++i){
			if(ttname==cname[i]){
	//			console.log(ttname,cname[i]);
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];				
				ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
				ttpdc+=LP_result[vname]*pCost[id_pc][j+2]*cusExc[cname[i]][j+2]; 
			}
		}
//	}

	trev += ttrev;
	tpdc += ttpdc;		
	tmarg += ttrev-ttpdc;
	trev_m.push(ttrev);
	tmarg_m.push(ttrev-ttpdc);
	tpdc_m.push(ttpdc);
	t_add_m[j] += ttrev;
	t_add += ttrev;
	t_add_all_m[j] += ttrev;
	t_add_all += ttrev;
	}


//	tdata.push([cusExc[ttname][0]].concat(trev_m).concat([trev]));
	if(cname.includes(ttname)){
		if(first_item==0){
//			tdata.push([cusExc[ttname][0],tname].concat(tpdc_m).concat([tpdc]));
			tdata.push([cusExc[ttname][0],tname].concat(trev_m).concat([trev]));				
			first_item=1;
		}else{
//			tdata.push(["",tname].concat(tpdc_m).concat([tpdc]));
			tdata.push(["",tname].concat(trev_m).concat([trev]));
		}		
/*
		if(tname=="NGL"){
			ttngl = ["","","m3"];
			for(ii=0;ii<tpdc_m.length;++ii){
				ttngl.push(tpdc_m[ii]/0.648);
			}
			ttngl.push(tpdc/0.648);
			tdata.push(ttngl);
		}
*/
	}
//	t_add_m.push(t_add);

	}
	tdata.push(["","Total"].concat(t_add_m).concat([t_add]));

	}

	tdata.push(["TOTAL",""].concat(t_add_all_m).concat([t_add_all]));
/*

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<cusName.length;++k){
			tt1+=tdata[k][i+1];
		}
		tt.push(tt1);
	}
	tdata.push(tt);
*/

	var html="<table id=prodRev12M  border=1><tr bgcolor=mediumblue><th>Customer</th><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			if(tdata[i][j]=="Total"||j==0){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(tdata[i][0]=="TOTAL" || tdata[i][1]=="Total" ){
				html += "<td align=right width=80><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=80>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodRev12M_table_new").innerHTML = html;
}

function create_prodCost12M_table_new(ccname){
	tdata=[];
	t_add_all_m=[];t_add_all=0;
	for(j=0;j<12;++j){
	t_add_all_m.push(0);
	}

	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	t_add_m=[];t_add=0;
	first_item=0;

	for(j=0;j<12;++j){
	t_add_m.push(0);
	}

	for (k=0;k<5;++k){
	tname = ""; 
	trev=0;tpdc=0;tmarg=0;
	trev_m=[];tpdc_m=[];tmarg_m=[];

	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
		

	for (j=0;j<12;++j){
	ttrev = 0;ttpdc=0;

		for (i=0;i<cname.length;++i){
			if(ttname==cname[i]){
	//			console.log(ttname,cname[i]);
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];				
				ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
				ttpdc+=LP_result[vname]*pCost[id_pc][j+2]*cusExc[cname[i]][j+2]; 
			}
		}
//	}

	trev += ttrev;
	tpdc += ttpdc;		
	tmarg += ttrev-ttpdc;
	trev_m.push(ttrev);
	tmarg_m.push(ttrev-ttpdc);
	tpdc_m.push(ttpdc);
	t_add_m[j] += ttpdc;
	t_add += ttpdc;
	t_add_all_m[j] += ttpdc;
	t_add_all += ttpdc;
	}


//	tdata.push([cusExc[ttname][0]].concat(trev_m).concat([trev]));
	if(cname.includes(ttname)){
		if(first_item==0){
			tdata.push([cusExc[ttname][0],tname].concat(tpdc_m).concat([tpdc]));
			first_item=1;
		}else{
			tdata.push(["",tname].concat(tpdc_m).concat([tpdc]));
		}		
/*
		if(tname=="NGL"){
			ttngl = ["","","m3"];
			for(ii=0;ii<tpdc_m.length;++ii){
				ttngl.push(tpdc_m[ii]/0.648);
			}
			ttngl.push(tpdc/0.648);
			tdata.push(ttngl);
		}
*/
	}
//	t_add_m.push(t_add);

	}
	tdata.push(["","Total"].concat(t_add_m).concat([t_add]));

	}

	tdata.push(["TOTAL",""].concat(t_add_all_m).concat([t_add_all]));
/*

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<cusName.length;++k){
			tt1+=tdata[k][i+1];
		}
		tt.push(tt1);
	}
	tdata.push(tt);
*/

	var html="<table id=prodCost12M  border=1><tr bgcolor=mediumblue><th>Customer</th><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			if(tdata[i][j]=="Total"||j==0){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(tdata[i][0]=="TOTAL" || tdata[i][1]=="Total" ){
				html += "<td align=right width=80><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=80>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodCost12M_table_new").innerHTML = html;
}

function create_prodMarg12M_table_new(ccname){
	tdata=[];
	t_add_all_m=[];t_add_all=0;
	for(j=0;j<12;++j){
	t_add_all_m.push(0);
	}

	for (cn=0;cn<cusName.length;++cn){
	ttname = cusName[cn];
	t_add_m=[];t_add=0;
	first_item=0;

	for(j=0;j<12;++j){
	t_add_m.push(0);
	}

	for (k=0;k<5;++k){
	tname = ""; 
	trev=0;tpdc=0;tmarg=0;
	trev_m=[];tpdc_m=[];tmarg_m=[];

	id_pc = 0;kk=0;
	cname=[];LP_result=[];ccPrice=[];
	if(k==0){ tname = "Ethane"; id_pc=0; cname=ccname[0][0]; kk=0; LP_result=LP_result_eth;den_tpm3=1;ccPrice=cusEthPrice;}
	if(k==1){ tname = "NGL"; id_pc=3; cname=ccname[1][0]; kk=0; LP_result=LP_result_ngl;den_tpm3=0.648;ccPrice=cusNglPrice;}
	if(k==2){ tname = "Propane"; id_pc=1; cname=ccname[2][0]; kk=0; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusProPrice;}
	if(k==3){ tname = "LPG-GSP"; id_pc=2; cname=ccname[2][1]; kk=1; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgPrice;}
	if(k==4){ tname = "LPG-Refinery"; id_pc=4; cname=ccname[2][2]; kk=2; LP_result=LP_result_proLpg;den_tpm3=1;ccPrice=cusLpgRefPrice;}
		

	for (j=0;j<12;++j){
	ttrev = 0;ttpdc=0;

		for (i=0;i<cname.length;++i){
			if(ttname==cname[i]){
	//			console.log(ttname,cname[i]);
				vname = cus_name(kk,i,j);
				pp = ccPrice[cname[i]];				
				ttrev+=LP_result[vname]*pp[j]*cusExc[cname[i]][j+2];
				ttpdc+=LP_result[vname]*pCost[id_pc][j+2]*cusExc[cname[i]][j+2]; 
			}
		}
//	}

	trev += ttrev;
	tpdc += ttpdc;		
	tmarg += ttrev-ttpdc;
	trev_m.push(ttrev);
	tmarg_m.push(ttrev-ttpdc);
	tpdc_m.push(ttpdc);
	ttmarg = ttrev-ttpdc;
	t_add_m[j] += ttmarg;
	t_add += ttmarg;
	t_add_all_m[j] += ttmarg;
	t_add_all += ttmarg;
	}


//	tdata.push([cusExc[ttname][0]].concat(trev_m).concat([trev]));
	if(cname.includes(ttname)){
		if(first_item==0){
//			tdata.push([cusExc[ttname][0],tname].concat(tpdc_m).concat([tpdc]));
			tdata.push([cusExc[ttname][0],tname].concat(trev_m).concat([trev]));				
			first_item=1;
		}else{
//			tdata.push(["",tname].concat(tpdc_m).concat([tpdc]));
			tdata.push(["",tname].concat(trev_m).concat([trev]));
		}		
/*
		if(tname=="NGL"){
			ttngl = ["","","m3"];
			for(ii=0;ii<tpdc_m.length;++ii){
				ttngl.push(tpdc_m[ii]/0.648);
			}
			ttngl.push(tpdc/0.648);
			tdata.push(ttngl);
		}
*/
	}
//	t_add_m.push(t_add);

	}
	tdata.push(["","Total"].concat(t_add_m).concat([t_add]));

	}

	tdata.push(["TOTAL",""].concat(t_add_all_m).concat([t_add_all]));
/*

	tt=["Total"];
	for(i=0;i<13;++i){
		tt1 = 0;
		for(k=0;k<cusName.length;++k){
			tt1+=tdata[k][i+1];
		}
		tt.push(tt1);
	}
	tdata.push(tt);
*/

	var html="<table id=prodMarg12M  border=1><tr bgcolor=mediumblue><th>Customer</th><th>Product</th><th>B1Jan-19</th><th>B1Feb-19</th><th>B1Mar-19</th><th>B1Apr-19</th><th>B1May-19</th><th>B1Jun-19</th><th>B1Jul-19</th><th>B1Aug-19</th><th>B1Sep-19</th><th>B1Oct-19</th><th>B1Nov-19</th><th>B1Dec-19</th><th>Total</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			if(tdata[i][j]=="Total"||j==0){
				html += "<td bgcolor=lightblue><b><font color=black>" + tdata[i][j] + "</font></b></td>";
			} else {
				html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
			}
		} else{
			if(tdata[i][0]=="TOTAL" || tdata[i][1]=="Total" ){
				html += "<td align=right width=80><b>" + numeral(tdata[i][j]).format('0,0') + "</b></td>";
			} else {
				html += "<td align=right width=80>" + numeral(tdata[i][j]).format('0,0') + "</td>";
			}
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("prodMarg12M_table_new").innerHTML = html;
}


cusNameAll=[[cusEth],[cusNgl],[cusPro,cusLpg,cusLpgRef]];
create_prodRev1y_table(cusNameAll);
create_prodRevBM_table(cusNameAll);
create_prodCostBM_table(cusNameAll);
create_prodMargBM_table(cusNameAll);
/*
create_prodRev12M_table(cusNameAll);
create_prodCost12M_table(cusNameAll);
create_prodMarg12M_table(cusNameAll);
*/
create_planCus12M_table(cusNameAll);
create_planTec12M_table(cusNameAll);
create_prodRev12M_table_new(cusNameAll);
create_prodCost12M_table_new(cusNameAll);
create_prodMarg12M_table_new(cusNameAll);

</script>
</body>
</html>
