function aarray_toString(aa){
	tmp_str="[";
	for (var j=0;j<aa.length;++j){
		tmp = array_toString(aa[j]);
		tmp_str+= tmp+",";
//		console.log(tmp_str + j);
	}
	if(tmp_str=="["){tmp_str+=",";}
	tmp_str = tmp_str.substring(0,tmp_str.length-1)+"]";
	return tmp_str;
}

function array_toString(aa){
	astr="[";
	for (var i=0;i<aa.length;++i){
	if(typeof(aa[i])=="string"){
		astr+='"'+aa[i].replace(/,/g,'')+'",';
	}
	if(typeof(aa[i])=="number"){
		astr+=aa[i] + ",";
	}
	}
	if(astr=="["){astr+=",";}
	astr = astr.substring(0,astr.length-1)+"]";
	return astr;
}

function dic_toString(aa){
	astr="{";
	var kk = Object.keys(aa);
	ss = kk.length;
	for (var j=0;j<ss;++j){
	astr+='"'+kk[j]+'":';
	if(typeof(aa[kk[j]])=="object"){
		astr+=array_toString(aa[kk[j]])+",";
	}
	if(typeof(aa[kk[j]])=="string"){
		astr+='"'+aa[kk[j]].replace(/,/g,'')+'",';
	}
	if(typeof(aa[kk[j]])=="number"){
		astr+=aa[kk[j]] + ",";
	}		
	}
	if(astr=="{"){astr+=",";}
	astr = astr.substring(0,astr.length-1)+"}";
	return astr;
}

function var_toString(aa){
	astr="";
	if(typeof(aa)=="string"){
		astr+='"'+aa.replace(/,/g,'')+'"';
	}
	if(typeof(aa)=="number"){
		astr+=aa;
	}
	return astr;
}

function cus_name(k,i,j){
	return 'c'+'p'+(k+1)+'c'+(i+1)+'m'+(j+1);
}
