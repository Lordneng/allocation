<!DOCTYPE html>
<html>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
}
	
th { color: white; font-size:10pt; }
</style>
<style>
@media print {
    body {-webkit-print-color-adjust: exact;}
    @page {size: A4 ;max-height:100%; max-width:100%}
    table {page-break-inside: avoid;}
}
</style>

<body>
<script src="glpk.min.js"></script>
<script src="numeral.min.js"></script>
<?php
echo "<script>";
//<script src="basic_data.js"></script>
echo file_get_contents('./basic_data.dat', FILE_USE_INCLUDE_PATH);
echo "</script>";
?>
<script src="conv_data.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<div style="position:relative; top:50px;">
<div align=center><h1>Production Estimation: Ethane</h1></div>
<font size=2>
<button onclick="myFunction()">Print this page</button><br><br>
<script>
function myFunction() {
  window.print();
}
</script>

<font size=4><b>Input:</b></font>&nbsp&nbsp
<input type=button value="Save Input" onclick="update_data()" ><br><br>

<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=ethInput_table></div>
</div>
<h2>Data:</h2>

<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=ethData_table></div><br><br>
<div id=ethDemand_table></div><br><br>
<div id=ethPrice_table></div><br><br>
</div>

<h2>Results:&nbsp <input type=button value="Calculate" onclick="run()">
&nbsp&nbsp<input type=button value="Clear" onclick="clear_result()">
&nbsp&nbsp<input type=button value="Save" onclick="update_data()">
</h2>
<script>
function clear_result() {
	LP_result={};
	create_ethResult_table(cusEth)
	create_ethRev_table(cusEth); 
}
</script>

<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=ethResult_table></div><br><br>
<div id=ethRev_table></div><br><br>
<div id=ethRepTot_table></div><br><br>
</div>
</font>

<div>
<form id="dataForm1" action="./data_write.php" method="post">
	<input type="hidden" name="yy">
	<input type="hidden" name="pCost">
	<input type="hidden" name="rPrice">
	<input type="hidden" name="estVol">
	<input type="hidden" name="maxLim">
	<input type="hidden" name="pttExc">
	<input type="hidden" name="cusName">
	<input type="hidden" name="cusExc">
	<input type="hidden" name="cusEth">
	<input type="hidden" name="cusEthData">
	<input type="hidden" name="cusNgl">
	<input type="hidden" name="cusNglData">
	<input type="hidden" name="invNgl">
	<input type="hidden" name="cusPro">
	<input type="hidden" name="cusLpg">
	<input type="hidden" name="cusLpgRef">
	<input type="hidden" name="cusProData">
	<input type="hidden" name="cusLpgData">
	<input type="hidden" name="cusLpgRefData">
	<input type="hidden" name="invProLpg">
	<input type="hidden" name="c3Constraint">
	<input type="hidden" name="LP_result_eth">
	<input type="hidden" name="LP_result_ngl">
	<input type="hidden" name="LP_result_proLpg">
	<input type="hidden" name="cusEthPrice">
	<input type="hidden" name="cusNglPrice">
	<input type="hidden" name="cusProPrice">
	<input type="hidden" name="cusLpgPrice">
	<input type="hidden" name="cusLpgRefPrice">
	<input type="submit" hidden>
</form>
</div>

<script>
/*
<textarea id="source" cols="50" rows="10"></textarea><br>
*/
</script>
<pre id="log" hidden>
</div>
<script>
var LP_result=LP_result_eth;
var start;
var logNode = document.getElementById("log");
var log = glp_print_func = function(value){
    var now = new Date();
        var d = (now.getTime() - start.getTime()) / 1000;
        logNode.appendChild(document.createTextNode(value + "\n"));
    if (d > 60) throw new Error("timeout");
        console.log(value);
};

function run(){
	result={};
	start = new Date(); 
	logNode.innerText = "";
	var lp = glp_create_prob();
	//    glp_read_lp_from_string(lp, null, document.getElementById("source").value);
	glp_read_lp_from_string(lp, null, LP_cmd);

	glp_scale_prob(lp, GLP_SF_AUTO);

	var smcp = new SMCP({presolve: GLP_ON});
	glp_simplex(lp, smcp);

	var iocp = new IOCP({presolve: GLP_ON});
	glp_intopt(lp, iocp);

	log("obj: " + glp_mip_obj_val(lp));
	result["obj"]=glp_mip_obj_val(lp);
	for(var i = 1; i <= glp_get_num_cols(lp); i++){
	log(glp_get_col_name(lp, i)  + " = " + glp_mip_col_val(lp, i));
		result[glp_get_col_name(lp, i)] = glp_mip_col_val(lp, i);
	}
	LP_result=result;
	create_ethResult_table(cusEth);
	create_ethRev_table(cusEth);
}
</script>

<script>
function arr_diff (a1, a2) {
    var a = [], diff = [];
    for (var i = 0; i < a1.length; i++) {
        a[a1[i]] = true;
    }
    for (var i = 0; i < a2.length; i++) {
        if (a[a2[i]]) {
            delete a[a2[i]];
        } else {
            a[a2[i]] = true;
        }
    }
    for (var k in a) {
        diff.push(k);
    }
    return diff;
}

function update_form(){
	document.getElementsByName("yy")[0].value = var_toString(yy);
	document.getElementsByName("pCost")[0].value = aarray_toString(pCost);
	document.getElementsByName("rPrice")[0].value = aarray_toString(rPrice);
	document.getElementsByName("estVol")[0].value = aarray_toString(estVol);
	document.getElementsByName("maxLim")[0].value = var_toString(maxLim);
	document.getElementsByName("pttExc")[0].value = aarray_toString(pttExc);
	document.getElementsByName("cusName")[0].value = array_toString(cusName);
	document.getElementsByName("cusExc")[0].value = dic_toString(cusExc);
	document.getElementsByName("cusEth")[0].value = array_toString(cusEth);
	document.getElementsByName("cusEthData")[0].value = dic_toString(cusEthData);
	document.getElementsByName("cusNgl")[0].value = array_toString(cusNgl);
	document.getElementsByName("cusNglData")[0].value = dic_toString(cusNglData);
	document.getElementsByName("invNgl")[0].value = array_toString(invNgl);	
	document.getElementsByName("cusPro")[0].value = array_toString(cusPro);
	document.getElementsByName("cusLpg")[0].value = array_toString(cusLpg);
	document.getElementsByName("cusLpgRef")[0].value = array_toString(cusLpgRef);
	document.getElementsByName("cusProData")[0].value = dic_toString(cusProData);
	document.getElementsByName("cusLpgData")[0].value = dic_toString(cusLpgData);
	document.getElementsByName("cusLpgRefData")[0].value = dic_toString(cusLpgRefData);
	document.getElementsByName("invProLpg")[0].value = aarray_toString(invProLpg);	
	document.getElementsByName("c3Constraint")[0].value = aarray_toString(c3Constraint);	
	document.getElementsByName("LP_result_eth")[0].value = dic_toString(LP_result);	
	document.getElementsByName("LP_result_ngl")[0].value = dic_toString(LP_result_ngl);	
	document.getElementsByName("LP_result_proLpg")[0].value = dic_toString(LP_result_proLpg);	
	document.getElementsByName("cusEthPrice")[0].value = dic_toString(ccPrice);	
	document.getElementsByName("cusNglPrice")[0].value = dic_toString(cusNglPrice);	
	document.getElementsByName("cusProPrice")[0].value = dic_toString(cusProPrice);	
	document.getElementsByName("cusLpgPrice")[0].value = dic_toString(cusLpgPrice);	
	document.getElementsByName("cusLpgRefPrice")[0].value = dic_toString(cusLpgRefPrice);	
}

function update_data(){
	get_table_update();
	update_form();
	document.getElementById("dataForm1").submit();
}


function create_ethInput_table(cname){
	tdata=[];
	for (i=0;i<cname.length;++i){
		tdata.push([cusExc[cname[i]][0]].concat(cusEthData[cname[i]]));
	}
	var html="<table id=ethInput border=1><tr bgcolor=mediumblue><th><font color=yellow>Ethane</font></th><th colspan=2>Regulation (Ton/hr)</th><th colspan=2>Pricing</th></tr>";
	html += "<tr bgcolor=mediumblue><th>Name</th><th>Max</th><th>Min</th><th>a</th><th>b</th><th>Pricing(a)</th><th>add/remove</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<1||j==5){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "<td align=center><a href='javascript:rem_cus_eth(" + '"' + cname[i] + '"' + ");'>remove</a></td>";
	html += "</tr>";
	}

	diffName = arr_diff(cusName,cname);
	html+= "<tr><td><select id=add_n>";
	for (i=0;i<diffName.length;++i){
	html += "<option value=" + '"' + diffName[i] + '"' + ">" + cusExc[diffName[i]][0] + "</option>";
	}
	html+= "</select>";
	for (i=0;i<4;++i){
	html += "<td id=add_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=add_4>";
	html += '<option value="HDPE">HDPE</option>';
	html += '<option value="CP">CP</option>';
	html += '<option value="MOP'+"'"+'J">MOP'+"'"+'J</option>';
	html+= "</select></td>";

	html += "<td align=center><a href='javascript:add_cus_eth()'>add</a></td>";
	html += "</tr>";

	html += "</table>"
	document.getElementById("ethInput_table").innerHTML = html;
}

function rem_cus_eth(cname){
	cc=Object.keys(cusEthData);
	var tmp = {};
	for( var i = 0; i < cc.length; i++){ 
	   if ( cc[i] != cname) {
	     tmp[cc[i]]=cusEthData[cc[i]]; 
	   }
	}
	cusEth = Object.keys(tmp);
	cusEthData = tmp;
	create_ethInput_table(cusEth);
}

function add_cus_eth(){
	add_n = document.getElementById("add_n").value;
	add_0 = Number(document.getElementById("add_0").innerHTML);
	add_1 = Number(document.getElementById("add_1").innerHTML);
	add_2 = Number(document.getElementById("add_2").innerHTML);
	add_3 = Number(document.getElementById("add_3").innerHTML);
	add_4 = document.getElementById("add_4").value;
	cusEthData[add_n] = [add_0,add_1,add_2,add_3,add_4];
	cusEth = Object.keys(cusEthData);
	create_ethInput_table(cusEth);
}

function create_ethData_table(cname){
	tdata=[['<b>Estimation Production</b>'].concat(estVol[0]),['<b>Production Cost</b>'].concat(pCost[0]),['<b>Exchange Rate</b>'].concat(pttExc[0])];
	result={};
	for (i=0;i<cname.length;++i){
		tdata.push([''].concat(cusExc[cname[i]]));
		tmp=[];
		for(j=0;j<12;++j){
			tmp.push(cusExc[cname[i]][j+2]);
		}
		result[cname[i]]=tmp;	
	}
	var html="<table id=ethData  border=1><tr bgcolor=mediumblue><th></th><th></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("ethData_table").innerHTML = html;
	return result;
}

function daysInMonth (month, year) {
    return new Date(year, month, 0).getDate();
}

function create_ethDemand_table(cname){
	tdata=[];result={};
	for (i=0;i<cname.length;++i){
		maxdata=[cusExc[cname[i]][0],'max','Ton'];
		mindata=['','min','Ton'];
		tmp_max=[];tmp_min=[];
		for (j=0;j<12;++j){
			tmp_max.push(24*daysInMonth(j+1,yy)*cusEthData[cname[i]][0]);
			tmp_min.push(24*daysInMonth(j+1,yy)*cusEthData[cname[i]][1]);	
		}
		tdata.push(maxdata.concat(tmp_max),mindata.concat(tmp_min));
		result[cname[i]]={"max":tmp_max,"min":tmp_min};
	}
	var html="<table border=1><tr bgcolor=mediumblue><th colspan=2>Demand Constraint</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}	
	
	//Production limit
	html += "<td colspan=2 bgcolor=lightblue><b>Production limit</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	prodLim=[];
	for (j=0;j<12;++j){
		tmp = estVol[0][j+2]*1000;
		prodLim.push(tmp);
		html += "<td align='right'><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	result["limit"]=prodLim;
	html += "</tr>";

	//Total Max
	html += "<td bgcolor=lightblue><b>Total</b></td><td bgcolor=lightblue><b>max</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp = 0;
		for (i=0;i<cname.length;++i){
			tmp += cusEthData[cname[i]][0];
		}
		tmp = tmp*24*daysInMonth(j+1,yy);
		html += "<td align='right'><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	//Total Min
	html += "<td bgcolor=lightblue></td><td bgcolor=lightblue><b>min</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp = 0;
		for (i=0;i<cname.length;++i){
			tmp += cusEthData[cname[i]][1];
		}
		tmp = tmp*24*daysInMonth(j+1,yy);
		html += "<td align='right'><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	html += "</table>"

	document.getElementById("ethDemand_table").innerHTML = html;
	return result;
}

function create_ethPrice_table(cname){
	tdata=[];result={};
	tmp=['HDPE(1 mth delay)','$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[0][i+2]);
	}
	tdata.push(tmp);

	tmp=["CP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[1][i+3]);
	}
	tdata.push(tmp);

	tmp=["MOP'J",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[4][i+3]);
	}
	tdata.push(tmp);

	for (i=0;i<cname.length;++i){
		pdata=[cusExc[cname[i]][0],'$/Ton'];
		tmp=[];
		for (j=0;j<12;++j){
			if(cusEthData[cname[i]][4]=="HDPE"){
			tmp.push((cusEthData[cname[i]][2]*rPrice[0][j+2] + cusEthData[cname[i]][3]).toFixed(2));
			}

			if(cusEthData[cname[i]][4]=="CP"){
			tmp.push((cusEthData[cname[i]][2]*rPrice[1][j+3] + cusEthData[cname[i]][3]).toFixed(2));
			}

			if(cusEthData[cname[i]][4]=="MOP'J"){
			tmp.push((cusEthData[cname[i]][2]*rPrice[4][j+3] + cusEthData[cname[i]][3]).toFixed(2));
			}

//			tmp.push((cusEthData[cname[i]][2]*rPrice[0][j+2] + cusEthData[cname[i]][3]).toFixed(2));
		}
		tdata.push(pdata.concat(tmp));
		result[cname[i]]=tmp;	
	}
	var html="<table border=1><tr bgcolor=mediumblue><th>Pricing(a*(var)+b)</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";	
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			if(i<3){
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			} else {
			html += "<td align='right' bgcolor=#cceeff width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("ethPrice_table").innerHTML = html;
	return result;
}

function create_ethResult_table(cname){
	tdata=[];
	
	if(LP_result==undefined || Object.keys(LP_result)==0){
	LP_result={};
		for(i=0;i<cname.length;++i){
			tmp = [cname[i],'Ton'];
			for (j=0;j<12;++j){
//				vname = 'c'+(i+1)+(j+1);
				vname = cus_name(0,i,j);
				LP_result[vname]=0;
//				tmp.push(LP_result[vname]);
			}
//			tdata.push(tmp);
		}
	LP_result['obj']=0;
	}

	for(i=0;i<cname.length;++i){
		tmp = [cusExc[cname[i]][0],'Ton'];
		for (j=0;j<12;++j){
//			vname = 'c'+(i+1)+(j+1);
			vname = cus_name(0,i,j);
			tmp.push(LP_result[vname]);
		}
		tdata.push(tmp);
	}

	//Total
	tmp_tot=['Total','Ton'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
//		vname = 'c'+(i+1)+(j+1);
		vname = cus_name(0,i,j);
		tmp += LP_result[vname];
		}
	tmp_tot.push(tmp);
	}
	tdata.push(tmp_tot);

	//Revenue(USD)
	tmp_rev=['Revenue','$'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
//		vname = 'c'+(i+1)+(j+1);
		vname = cus_name(0,i,j);
		tmp += LP_result[vname]*ccPrice[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(THB)
	tmp_rev=['Revenue','THB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
//		vname = 'c'+(i+1)+(j+1);
		vname = cus_name(0,i,j);
		tmp += LP_result[vname]*ccPrice[cname[i]][j]*ccExcRate[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(MB)
	tmp_rev=['Revenue','MB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
//		vname = 'c'+(i+1)+(j+1);
		vname = cus_name(0,i,j);
		tmp += LP_result[vname]*ccPrice[cname[i]][j]*ccExcRate[cname[i]][j]/1000000;
		}
	tmp_rev.push(tmp);
	}
	tdata.push(tmp_rev);


	var html="<table id=ethResult border=1><tr bgcolor=mediumblue><th>Ethane</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else 
		if( i<cname.length){
		html += "<td align=right bgcolor='F9FF7E'>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}else
		if(i==cname.length+3){
		html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		} else {
		html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}

	}
	html += "</tr>";
	}		

	html += "</table>"

	document.getElementById("ethResult_table").innerHTML = html;
}

function create_LP_cmd(cname){
	lp_obj="Maximize\n obj: ";
	for(i=0;i<cname.length;++i){
		for(j=0;j<12;++j){
//			vname = 'c'+(i+1)+(j+1);
			vname = cus_name(0,i,j);
			lp_obj += ' + ' + (ccPrice[cname[i]][j]*ccExcRate[cname[i]][j]).toFixed(3) + ' ' + vname;
		}
	}
	lp_obj+='\n\n';

	lp_obj+='Subject To\n ';
	for(j=0;j<12;++j){
		lp_obj += 's'+(j+1)+': ';
		for(i=0;i<cname.length;++i){
//			vname = 'c'+(i+1)+(j+1);
			vname = cus_name(0,i,j);
			lp_obj += ' + ' + vname;
		}
		lp_obj += ' <= ' + ccDemand['limit'][j] + '\n ';
	}
	lp_obj+='\n';

	lp_obj+='Bounds\n ';
	for(i=0;i<cname.length;++i){
		for(j=0;j<12;++j){
//			vname = 'c'+(i+1)+(j+1);
			vname = cus_name(0,i,j);
			lp_obj += ''+ ccDemand[cname[i]]['min'][j] + " <= " + vname + " <= " + ccDemand[cname[i]]['max'][j] + '\n ';
		}
	}
	lp_obj+='\nEnd\n';

//	document.getElementById("source").value = lp_obj;
	return lp_obj;
}

function table_data(tname){
	var myTableArray = [];

	$("table#"+tname+" tr").each(function() {
	    var arrayOfThisRow = [];
	    var tableData = $(this).find('td');
	    if (tableData.length > 0) {
		tableData.each(function() { arrayOfThisRow.push($(this).text()); });
		myTableArray.push(arrayOfThisRow);
	    }
	});

	for(i=0;i<myTableArray.length;++i){
		for(j=0;j<myTableArray[i].length;++j){
		if(j>0){
			myTableArray[i][j] = myTableArray[i][j].replace(/,/g,'');
		}
		}
	}
	return myTableArray;
}

function get_table_update(){
	ethInput = table_data("ethInput");
	for(i=0;i<cusEth.length;++i){
		for(j=0;j<cusEthData[cusEth[i]].length;++j){
			if(j<cusEthData[cusEth[i]].length-1){
			cusEthData[cusEth[i]][j] = Number(ethInput[i][j+1]);
			} else{
			cusEthData[cusEth[i]][j] = ethInput[i][j+1];
			}
		}
	}
}

function create_ethRev_table(cname){
	tdata=[];result={};
	tmp_data = table_data("ethData");
	rev_data = table_data("ethResult");
	var rev=0.0;
	var prod=0.0;
	var marg=0.0;
	for (i=0;i<12;++i){
		prod += Number(tmp_data[0][i+3])*Number(tmp_data[1][i+3])*Number(tmp_data[2][i+3]);
		rev += Number(rev_data[rev_data.length-2][i+2]);
	}
	prod = 1000.0*prod;
	marg = rev-prod;

//	tdata.push(["<b>Revenue(THB)</b>",rev.toFixed(2)],["<b>Production(THB)</b>",prod.toFixed(2)],["<b>Margin(THB)</b>",marg.toFixed(2)]);
	tdata.push(["<b>Revenue(THB)</b>",numeral(rev).format('0,0')],["<b>Production(THB)</b>",numeral(prod).format('0,0')],["<b>Margin(THB)</b>",numeral(marg).format('0,0')]);


	var html="<table border=1>";
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	html += "<td bgcolor=mediumblue><font color=white>" + tdata[i][0] + "</font></td>";
	html += "<td align='right' width=120>" + tdata[i][1] + "</td>";
	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("ethRev_table").innerHTML = html;
	return result;
}

create_ethInput_table(cusEth);
ccExcRate=create_ethData_table(cusEth);
ccDemand=create_ethDemand_table(cusEth);
ccPrice=create_ethPrice_table(cusEth);
LP_cmd=create_LP_cmd(cusEth);
create_ethResult_table(cusEth);
create_ethRev_table(cusEth);
//update_form();

</script>
</body>
</html>
