<!DOCTYPE html>
<html>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
}
th { color: white; font-size:10pt;}
</style>
<style>
@media print {
    body {-webkit-print-color-adjust: exact;}
    @page {size: A4 ;max-height:100%; max-width:100%}
    table {page-break-inside: avoid;}
}
</style>
<body>
<script src="glpk.min.js"></script>
<script src="numeral.min.js"></script>
<?php
echo "<script>";
//<script src="basic_data.js"></script>
echo file_get_contents('./basic_data.dat', FILE_USE_INCLUDE_PATH);
echo "</script>";
?>
<script src="conv_data.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<div style="position:relative; top:50px;">
<div align=center><h1>Production Estimation: NGL</h1></div>
<font size=2>
<button onclick="myFunction()">Print this page</button><br><br>

<script>
function myFunction() {
  window.print();
}
</script>

<font size=4><b>Input:</b></font>&nbsp&nbsp
<input type=button value="Save Input" onclick="update_data()" >
<br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=maxLim_table></div><br><br>
<div id=nglInput_table></div><br><br>
<div id=invNgl_table></div><br><br>
</div>

<h2>Data:</h2>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=nglData_table></div><br><br>
<div id=nglDemand_table></div><br><br>
<div id=nglPrice_table></div><br><br>
</div>

<h2>Results:&nbsp <input type=button value="Calculate" onclick="run()">
&nbsp&nbsp<input type=button value="Clear" onclick="clear_result()">
&nbsp&nbsp<input type=button value="Save" onclick="update_data()">
</h2>
<script>
function clear_result() {
	LP_result={};
	create_nglResult_table(cusNgl)
	create_nglRev_table(cusNgl); 
}
</script>

<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=nglResult_table></div><br><br>
<div id=nglRev_table></div><br><br>
<div id=ethRepTot_table></div><br><br>
</div>
</font>

<div>
<form id="dataForm1" action="./data_write.php" method="post">
	<input type="hidden" name="yy">
	<input type="hidden" name="pCost">
	<input type="hidden" name="rPrice">
	<input type="hidden" name="estVol">
	<input type="hidden" name="maxLim">
	<input type="hidden" name="pttExc">
	<input type="hidden" name="cusName">
	<input type="hidden" name="cusExc">
	<input type="hidden" name="cusEth">
	<input type="hidden" name="cusEthData">
	<input type="hidden" name="cusNgl">
	<input type="hidden" name="cusNglData">
	<input type="hidden" name="invNgl">
	<input type="hidden" name="cusPro">
	<input type="hidden" name="cusLpg">
	<input type="hidden" name="cusLpgRef">
	<input type="hidden" name="cusProData">
	<input type="hidden" name="cusLpgData">
	<input type="hidden" name="cusLpgRefData">
	<input type="hidden" name="invProLpg">
	<input type="hidden" name="c3Constraint">
	<input type="hidden" name="LP_result_eth">
	<input type="hidden" name="LP_result_ngl">
	<input type="hidden" name="LP_result_proLpg">
	<input type="hidden" name="cusEthPrice">
	<input type="hidden" name="cusNglPrice">
	<input type="hidden" name="cusProPrice">
	<input type="hidden" name="cusLpgPrice">
	<input type="hidden" name="cusLpgRefPrice">
	<input type="submit" hidden>
</form>
</div>

<script>
/*
<textarea id="source" cols="50" rows="10"></textarea><br>
*/
</script>
<pre id="log" hidden>
</div>
<script>
den_tpm3=0.648;
bbl2l=158.987;
var LP_result=LP_result_ngl;
var start;
var logNode = document.getElementById("log");
var log = glp_print_func = function(value){
    var now = new Date();
        var d = (now.getTime() - start.getTime()) / 1000;
        logNode.appendChild(document.createTextNode(value + "\n"));
    if (d > 60) throw new Error("timeout");
        console.log(value);
};

function run(){
	result={};
	start = new Date(); 
	logNode.innerText = "";
	var lp = glp_create_prob();
	//    glp_read_lp_from_string(lp, null, document.getElementById("source").value);
	glp_read_lp_from_string(lp, null, LP_cmd);

	glp_scale_prob(lp, GLP_SF_AUTO);

	var smcp = new SMCP({presolve: GLP_ON});
	glp_simplex(lp, smcp);

	var iocp = new IOCP({presolve: GLP_ON});
	glp_intopt(lp, iocp);

	log("obj: " + glp_mip_obj_val(lp));
	result["obj"]=glp_mip_obj_val(lp);
	for(var i = 1; i <= glp_get_num_cols(lp); i++){
	log(glp_get_col_name(lp, i)  + " = " + glp_mip_col_val(lp, i));
		result[glp_get_col_name(lp, i)] = glp_mip_col_val(lp, i);
	}
	LP_result=result;
	create_nglResult_table(cusNgl);
	create_nglRev_table(cusEth);

}
</script>

<script>
function arr_diff (a1, a2) {
    var a = [], diff = [];
    for (var i = 0; i < a1.length; i++) {
        a[a1[i]] = true;
    }
    for (var i = 0; i < a2.length; i++) {
        if (a[a2[i]]) {
            delete a[a2[i]];
        } else {
            a[a2[i]] = true;
        }
    }
    for (var k in a) {
        diff.push(k);
    }
    return diff;
}

function update_form(){
	document.getElementsByName("yy")[0].value = var_toString(yy);
	document.getElementsByName("pCost")[0].value = aarray_toString(pCost);
	document.getElementsByName("rPrice")[0].value = aarray_toString(rPrice);
	document.getElementsByName("estVol")[0].value = aarray_toString(estVol);
	document.getElementsByName("maxLim")[0].value = var_toString(maxLim);
	document.getElementsByName("pttExc")[0].value = aarray_toString(pttExc);
	document.getElementsByName("cusName")[0].value = array_toString(cusName);
	document.getElementsByName("cusExc")[0].value = dic_toString(cusExc);
	document.getElementsByName("cusEth")[0].value = array_toString(cusEth);
	document.getElementsByName("cusEthData")[0].value = dic_toString(cusEthData);
	document.getElementsByName("cusNgl")[0].value = array_toString(cusNgl);
	document.getElementsByName("cusNglData")[0].value = dic_toString(cusNglData);
	document.getElementsByName("invNgl")[0].value = array_toString(invNgl);	
	document.getElementsByName("cusPro")[0].value = array_toString(cusPro);
	document.getElementsByName("cusLpg")[0].value = array_toString(cusLpg);
	document.getElementsByName("cusLpgRef")[0].value = array_toString(cusLpgRef);
	document.getElementsByName("cusProData")[0].value = dic_toString(cusProData);
	document.getElementsByName("cusLpgData")[0].value = dic_toString(cusLpgData);
	document.getElementsByName("cusLpgRefData")[0].value = dic_toString(cusLpgRefData);
	document.getElementsByName("invProLpg")[0].value = aarray_toString(invProLpg);	
	document.getElementsByName("c3Constraint")[0].value = aarray_toString(c3Constraint);	
	document.getElementsByName("LP_result_eth")[0].value = dic_toString(LP_result_eth);	
	document.getElementsByName("LP_result_ngl")[0].value = dic_toString(LP_result);	
	document.getElementsByName("LP_result_proLpg")[0].value = dic_toString(LP_result_proLpg);
	document.getElementsByName("cusEthPrice")[0].value = dic_toString(cusEthPrice);	
	document.getElementsByName("cusNglPrice")[0].value = dic_toString(ccPrice);	
	document.getElementsByName("cusProPrice")[0].value = dic_toString(cusProPrice);	
	document.getElementsByName("cusLpgPrice")[0].value = dic_toString(cusLpgPrice);	
	document.getElementsByName("cusLpgRefPrice")[0].value = dic_toString(cusLpgRefPrice);
}

function update_data(){
	get_table_update();
	update_form();
	document.getElementById("dataForm1").submit();
}

function create_maxLim_table(tdata){
	var html="<table id=TmaxLim  border=1><tr>";
	html += "<td bgcolor=mediumblue><font color=white><b>Maximum limit</b></font></td>";
	html += "<td bgcolor='#FF927E' contenteditable='true'>"+tdata+"</td>";
	html += "</tr></table>";
	document.getElementById("maxLim_table").innerHTML = html;
}

function create_nglInput_table(cname){
	tdata=[];
	for (i=0;i<cname.length;++i){
		tdata.push([cusExc[cname[i]][0]].concat(cusNglData[cname[i]]));
	}
	var html="<table id=nglInput border=1><tr bgcolor=mediumblue><th><font color=yellow>NGL</font></th><th colspan=3>Regulation</th><th colspan=2>Pricing</th><th colspan=3>Extra constraint</th></tr>";
	html += "<tr bgcolor=mediumblue><th>Name</th><th>Unit</th><th>Max</th><th>Min</th><th>a</th><th>b</th><th>Unit</th><th>Max</th><th>Min</th><th>Pricing(a)<th>add/remove</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2 || j==6 || j==9){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else if(j>6){
		if(tdata[i][6]=="--"){ 
		html += "<td>" + tdata[i][j] +"</td>";		
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "<td align=center><a href='javascript:rem_cus_ngl(" + '"' + cname[i] + '"' + ");'>remove</a></td>";
	html += "</tr>";
	}

	diffName = arr_diff(cusName,cname);
	html+= "<tr><td><select id=add_n>";
	for (i=0;i<diffName.length;++i){
	html += "<option value=" + '"' + diffName[i] + '"' + ">" + cusExc[diffName[i]][0] + "</option>";
	}
	html+= "</select></td>";

	html+= "<td><select id=add_0>";
	html += '<option value="Km3/month">Km3/month</option>';
	html += '<option value="KT/month">KT/month</option>';
	html += '<option value="Ton/hr">Ton/hr</option>';
	html+= "</select></td>";

	for (i=1;i<5;++i){
	html += "<td id=add_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=add_5>";
	html += '<option value="--">--</option>';
	html += '<option value="Km3/year">Km3/year</option>';
	html += '<option value="KT/year">KT/year</option>';
	html+= "</select></td>";

	for (i=6;i<8;++i){
	html += "<td id=add_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=add_8>";
	html += '<option value="MOP'+"'"+'J">MOP'+"'"+'J</option>';
	html += '<option value="MOP'+"'"+'S">MOP'+"'"+'S</option>';
	html+= "</select></td>";

	html += "<td align=center><a href='javascript:add_cus_ngl()'>add</a></td>";
	html += "</tr>";
	html += "</table>"
	document.getElementById("nglInput_table").innerHTML = html;
}

function rem_cus_ngl(cname){
	cc=Object.keys(cusNglData);
	var tmp = {};
	for( var i = 0; i < cc.length; i++){ 
	   if ( cc[i] != cname) {
	     tmp[cc[i]]=cusNglData[cc[i]]; 
	   }
	}
	cusNgl = Object.keys(tmp);
	cusNglData = tmp;
	create_nglInput_table(cusNgl);
}

function add_cus_ngl(){
	add_n = document.getElementById("add_n").value;
	add_0 = document.getElementById("add_0").value;
	add_1 = document.getElementById("add_1").innerHTML;
	add_2 = Number(document.getElementById("add_2").innerHTML);
	add_3 = Number(document.getElementById("add_3").innerHTML);
	add_4 = Number(document.getElementById("add_4").innerHTML);
	add_5 = document.getElementById("add_5").value;
	add_6 = document.getElementById("add_6").innerHTML;
	add_7 = Number(document.getElementById("add_7").innerHTML);
	add_8 = document.getElementById("add_8").value;
	if(add_1!="max"){ 
		add_1 = Number(add_1); 
		if(add_1>maxLim||isNaN(add_1)){add_1=maxLim;}
	}else{add_1=maxLim;}
	if(add_6!="max"){ 
		add_6 = Number(add_6);
		if(add_6>maxLim||isNaN(add_6)){add_6=maxLim;}
	}else{add_6=maxLim;}
	if(add_5=="--"){
		add_6=0; add_7=0;
	}
	cusNglData[add_n] = [add_0,add_1,add_2,add_3,add_4,add_5,add_6,add_7,add_8];
	cusNgl = Object.keys(cusNglData);
	create_nglInput_table(cusNgl);
}

function create_invNgl_table(cdata){
	tdata=[['<b>NGL</b>'].concat(cdata)];
	var html="<table id=TinvNgl  border=1><tr bgcolor=mediumblue><th>Inventory Constraint</th><th>Capacity(m3)</th><th>Max(%)</th><th>Min(%)</th><th>Current</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j==0){
		html += "<td>" + tdata[i][j] + "</td>";
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("invNgl_table").innerHTML = html;
}


/////////////////////////// Data section ////////////////////////////////////

function create_nglData_table(cname){
	tdata=[['<b>Estimation Production</b>'].concat(estVol[3])];
	tmp_d = [];
	for(i=2;i<estVol[3].length;++i){
		tmp_d.push(Number((estVol[3][i]*1000*den_tpm3).toFixed(3)));
	}
	prodEst=tmp_d;
	prodCost=pCost[3];
	tdata.push(['','(*1000*'+den_tpm3+')','Ton'].concat(tmp_d));
	tdata.push(['<b>Production Cost</b>'].concat(pCost[3]));
	tdata.push(['<b>Exchange Rate</b>'].concat(pttExc[0]));
	result={};
	for (i=0;i<cname.length;++i){
		tdata.push([''].concat(cusExc[cname[i]]));
		tmp=[];
		for(j=0;j<12;++j){
			tmp.push(cusExc[cname[i]][j+2]);
		}
		result[cname[i]]=tmp;	
	}
	var html="<table id=nglData  border=1><tr bgcolor=mediumblue><th></th><th></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right'  width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("nglData_table").innerHTML = html;
	return result;
}


function daysInMonth (month, year) {
    return new Date(year, month, 0).getDate();
}

function create_nglDemand_table(cname){
	tdata=[];result={};
	for (i=0;i<cname.length;++i){
		maxdata=[cusExc[cname[i]][0],'max','Ton'];
		mindata=['','min','Ton'];
		tmp_max=[];tmp_min=[];
		for (j=0;j<12;++j){
		if(cusNglData[cname[i]][0]=="Ton/hr"){
			tmp_max.push(Math.min(24*daysInMonth(j+1,yy)*cusNglData[cname[i]][1],maxLim));
			tmp_min.push(24*daysInMonth(j+1,yy)*cusNglData[cname[i]][2]);	
		}
		if(cusNglData[cname[i]][0]=="KT/month"){
			tmp_max.push(Math.min(cusNglData[cname[i]][1]*1000,maxLim));
			tmp_min.push(cusNglData[cname[i]][2]*1000);	
		}
		if(cusNglData[cname[i]][0]=="Km3/month"){
			tmp_max.push(Math.min(cusNglData[cname[i]][1]*1000*den_tpm3,maxLim));
			tmp_min.push(cusNglData[cname[i]][2]*1000*den_tpm3);	
		}
		}
		tdata.push(maxdata.concat(tmp_max),mindata.concat(tmp_min));
		result[cname[i]]={"max":tmp_max,"min":tmp_min};
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th colspan=2>Demand Constraint</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}	
	
	//Production limit
	html += "<td bgcolor=lightblue colspan=2><b>Production limit</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	prodLim=[];
	for (j=0;j<12;++j){
		tmp = (estVol[3][j+2]*1000*den_tpm3).toFixed(3);
		prodLim.push(Number(tmp));
		html += "<td align=right><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	result["limit"]=prodLim;
	html += "</tr>";

	//Total Max
	html += "<td bgcolor=lightblue><b>Total</b></td><td bgcolor=lightblue><b>max</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_max = 0;
		for (i=0;i<cname.length;++i){
		if(cusNglData[cname[i]][0]=="Ton/hr"){
			tmp_max += (Math.min(24*daysInMonth(j+1,yy)*cusNglData[cname[i]][1],maxLim));
		}
		if(cusNglData[cname[i]][0]=="KT/month"){
			tmp_max += (Math.min(cusNglData[cname[i]][1]*1000,maxLim));
		}
		if(cusNglData[cname[i]][0]=="Km3/month"){
			tmp_max += (Math.min(cusNglData[cname[i]][1]*1000*den_tpm3,maxLim));
		}
		}
		html += "<td align=right><b>"+numeral(tmp_max).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	//Total Min
	html += "<td bgcolor=lightblue></td><td bgcolor=lightblue><b>min</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_min = 0;
		for (i=0;i<cname.length;++i){
		if(cusNglData[cname[i]][0]=="Ton/hr"){
			tmp_min += (24*daysInMonth(j+1,yy)*cusNglData[cname[i]][2]);	
		}
		if(cusNglData[cname[i]][0]=="KT/month"){
			tmp_min += (cusNglData[cname[i]][2]*1000);	
		}
		if(cusNglData[cname[i]][0]=="Km3/month"){
			tmp_min += (cusNglData[cname[i]][2]*1000*den_tpm3);	
		}
		}
		html += "<td align=right><b>"+numeral(tmp_min).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	html += "</table>"

	document.getElementById("nglDemand_table").innerHTML = html;
	return result;
}

function create_nglPrice_table(cname){
	tdata=[];result={};
	tmp=["MOP'J",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[4][i+3]);
	}
	tdata.push(tmp);
	tmp=["MOP'S",'$/bbl'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[5][i+3]);
	}
	tdata.push(tmp);

	mop_dt = [];	
	for (i=0;i<12;++i){
	mop_dt.push((rPrice[5][i+3]*1000/(bbl2l*den_tpm3)).toFixed(3)); 
	}
	tdata.push(["","$/Ton"].concat(mop_dt));

	for (i=0;i<cname.length;++i){
		pdata=[cusExc[cname[i]][0],'$/Ton'];
		tmp=[];
		for (j=0;j<12;++j){
		if(cusNglData[cname[i]][8]=="MOP'J"){
		tt = (cusNglData[cname[i]][3]*rPrice[4][j+3] + cusNglData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}
		if(cusNglData[cname[i]][8]=="MOP'S"){
		tt = (cusNglData[cname[i]][3]*rPrice[5][j+3] + cusNglData[cname[i]][4])*1000/(bbl2l*den_tpm3);
		tmp.push(Number(tt.toFixed(3)));
		}
		}
		tdata.push(pdata.concat(tmp));
		result[cname[i]]=tmp;	
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th>Pricing<br>(a*(MOP'J||MOP'S)+b)</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			if(i<3){
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}else{
			html += "<td align='right' bgcolor=#cceeff width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}
		}
	}
	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("nglPrice_table").innerHTML = html;
	return result;
}



function table_data(tname){
	var myTableArray = [];

	$("table#"+tname+" tr").each(function() {
	    var arrayOfThisRow = [];
	    var tableData = $(this).find('td');
	    if (tableData.length > 0) {
		tableData.each(function() { arrayOfThisRow.push($(this).text()); });
		myTableArray.push(arrayOfThisRow);
	    }
	});

	for(i=0;i<myTableArray.length;++i){
		for(j=0;j<myTableArray[i].length;++j){
		if(j>0){
			myTableArray[i][j] = myTableArray[i][j].replace(/,/g,'');
		}
		}
	}
	return myTableArray;
}

function get_table_update(){
	nglInput = table_data("nglInput");
	for(i=0;i<cusNgl.length;++i){
		for(j=0;j<cusNglData[cusNgl[i]].length;++j){
			if(j==0||j==5||j==8){
			cusNglData[cusNgl[i]][j] = nglInput[i][j+1];
			} else if(j==1||j==6){
			if(isNaN(Number(nglInput[i][j+1]))) {nglInput[i][j+1]=maxLim;}
			cusNglData[cusNgl[i]][j] = Math.min(maxLim,Number(nglInput[i][j+1]));
			} else{
			cusNglData[cusNgl[i]][j] = Number(nglInput[i][j+1]);
			}
		}
	}

	TmaxLim = table_data("TmaxLim");
	tmp_maxLim = Number(TmaxLim[0][1]);
	for(i=0;i<cusNgl.length;++i){
		if(cusNglData[cusNgl[i]][1]==maxLim){
			cusNglData[cusNgl[i]][1]=tmp_maxLim;
		}
		if(cusNglData[cusNgl[i]][6]==maxLim){
			cusNglData[cusNgl[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusPro.length;++i){
		if(cusProData[cusPro[i]][1]==maxLim){
			cusProData[cusPro[i]][1]=tmp_maxLim;
		}
		if(cusProData[cusPro[i]][6]==maxLim){
			cusProData[cusPro[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusLpg.length;++i){
		if(cusLpgData[cusLpg[i]][1]==maxLim){
			cusLpgData[cusLpg[i]][1]=tmp_maxLim;
		}
		if(cusLpgData[cusLpg[i]][6]==maxLim){
			cusLpgData[cusLpg[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusLpgRef.length;++i){
		if(cusLpgRefData[cusLpgRef[i]][1]==maxLim){
			cusLpgRefData[cusLpgRef[i]][1]=tmp_maxLim;
		}
	}
	maxLim = tmp_maxLim;

	TinvNgl = table_data("TinvNgl");
	invNgl = [Number(TinvNgl[0][1]),Number(TinvNgl[0][2]),Number(TinvNgl[0][3]),Number(TinvNgl[0][4])];
}

function create_LP_cmd(cname){
	lp_obj="Maximize\n obj: ";
	for(i=0;i<cname.length;++i){
		for(j=0;j<12;++j){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			lp_obj += ' + ' + (ccPrice[cname[i]][j]*ccExcRate[cname[i]][j]).toFixed(3) + ' ' + vname;
		}
	}
	lp_obj+='\n\n';

	lp_obj+='Subject To\n ';

	count=1;
/*
	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		for(i=0;i<cname.length;++i){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
//		tmp_cond=(prodEst[j] - invConst[0]+invConst[3] - invConst[2]);
//		lp_obj += ' <= ' + Math.min(ccDemand['limit'][j],tmp_cond) + '\n ';
		lp_obj += ' <= ' + ccDemand['limit'][j] + '\n ';
	}
*/
////inventory constraint

	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		if(j==0){
		for(i=0;i<cname.length;++i){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
		lp_obj += ' <= ' + (prodEst[j] + invConst[3] - invConst[2]) + '\n ';
		}else{
		for(i=0;i<cname.length;++i){
			for(k=0;k<=j;++k){
			vname = cus_name(0,i,k);//'c'+(i+1)+(k+1);
			lp_obj += ' + ' + vname;
			}
		}
		s_proEst=0;
		for(k=0;k<=j;++k){
			s_proEst+=prodEst[k];
		}
		lp_obj += ' <= ' + (s_proEst + invConst[3] - invConst[2]) + '\n ';
		}
	}

	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		if(j==0){
		for(i=0;i<cname.length;++i){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
		lp_obj += ' >= ' + (prodEst[j] + invConst[3] - invConst[1]) + '\n ';
		}else{
		for(i=0;i<cname.length;++i){
			for(k=0;k<=j;++k){
			vname = cus_name(0,i,k);//'c'+(i+1)+(k+1);
			lp_obj += ' + ' + vname;
			}
		}
		s_proEst=0;
		for(k=0;k<=j;++k){
			s_proEst+=prodEst[k];
		}
		lp_obj += ' >= ' + (s_proEst + invConst[3] - invConst[1]) + '\n ';
		}
	}

/////extra constraint
//	cc = 3*12+1;
	for(i=0;i<cname.length;++i){
	if(extraConst[cname[i]].length>0){
		tmp_obj ="";
		for(j=0;j<12;++j){
		vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
		tmp_obj += ' + ' + vname;
		}
		lp_obj += 's'+(count++)+': ' + tmp_obj + ' <= ' + extraConst[cname[i]][0] + '\n ';		
		lp_obj += 's'+(count++)+': ' + tmp_obj + ' >= ' + extraConst[cname[i]][1] + '\n ';	
		cc+=2;			
	}
	}

	lp_obj+='\n';

	lp_obj+='Bounds\n ';
	for(i=0;i<cname.length;++i){
		for(j=0;j<12;++j){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			lp_obj += ''+ ccDemand[cname[i]]['min'][j] + " <= " + vname + " <= " + ccDemand[cname[i]]['max'][j] + '\n ';
		}
	}
	lp_obj+='\nEnd\n';

//	document.getElementById("source").value = lp_obj;
	return lp_obj;
}


/////////////////////////// Results section ////////////////////////////////////


function create_nglResult_table(cname){
	tdata=[];
	
	if(LP_result==undefined || Object.keys(LP_result)==0){
	LP_result={};
		for(i=0;i<cname.length;++i){
			tmp = [cname[i],'Ton'];
			for (j=0;j<12;++j){
				vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
				LP_result[vname]=0;
//				tmp.push(LP_result[vname]);
			}
//			tdata.push(tmp);
		}
	}

	for(i=0;i<cname.length;++i){
		tmp = [cusExc[cname[i]][0],'Ton'];
		for (j=0;j<12;++j){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			tmp.push(LP_result[vname].toFixed(2));
		}
		tdata.push(tmp);
	}

	//Total
	tmp_tot=['Total','Ton'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
		tmp += LP_result[vname];
		}
	tmp_tot.push(tmp.toFixed(2));
	}
	tdata.push(tmp_tot);

	//Production
	tmp_prod=['Production','Ton'];
	for(j=0;j<12;++j){
		tmp = prodEst[j];
		tmp_prod.push(tmp.toFixed(2));
	}
	tdata.push(tmp_prod);

	//Inventory
	pre_inv=Number(invConst[3]);
	tmp_inv=['Inventory','m3'];
	for(j=0;j<12;++j){
		tmp = -Number(tmp_tot[j+2])+Number(tmp_prod[j+2])+pre_inv;
		tmp_inv.push((tmp/den_tpm3).toFixed(2));
		pre_inv = tmp;
	}
	tdata.push(tmp_inv);

	//Revenue(USD)
	tmp_rev=['Revenue','USD'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
		tmp += LP_result[vname]*ccPrice[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(THB)
	tmp_rev=['Revenue','THB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
		tmp += LP_result[vname]*ccPrice[cname[i]][j]*ccExcRate[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(MB)
	tmp_rev=['Revenue','MB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
//		vname = 'c'+(i+1)+(j+1);
		vname = cus_name(0,i,j);
		tmp += LP_result[vname]*ccPrice[cname[i]][j]*ccExcRate[cname[i]][j]/1000000;
		}
	tmp_rev.push(tmp);
	}
	tdata.push(tmp_rev);

	var html="<table id=nglResult  border=1><tr bgcolor=mediumblue><th>NGL</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else 
		if( i<cname.length){
		html += "<td align=right bgcolor='F9FF7E'>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}else
		if(i==cname.length+3){
		html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		} else {
		html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}		

	html += "</table>"

	document.getElementById("nglResult_table").innerHTML = html;
}


function create_nglRev_table(cname){
	tdata=[];result={};
	tmp_data = table_data("nglData");
	rev_data = table_data("nglResult");
	var prod=0;
	var marg=0;
	var revNgl=0;
	for (i=0;i<12;++i){
		prod += tmp_data[0][i+3]*tmp_data[2][i+3]*tmp_data[3][i+3];
		revNgl += Number(rev_data[rev_data.length-2][i+2]);
	}
	prod = 1000.0*den_tpm3*prod;
	marg = revNgl-prod;

	tdata.push(["<b>Revenue(THB)</b>",revNgl],["<b>Production(THB)</b>",prod],["<b>Margin(THB)</b>",marg]);
//	tdata.push(["<b>Revenue(THB)</b>",Number(LP_result['obj']).toFixed(2)],["<b>Production(THB)</b>",prod.toFixed(2)],["<b>Margin(THB)</b>",marg.toFixed(2)]);

	var html="<table border=1>";
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	html += "<td bgcolor=mediumblue><font color=white>" + tdata[i][0] + "</font></td>";
	html += "<td align='right' width=120>" + numeral(tdata[i][1]).format('0,0') + "</td>";
	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("nglRev_table").innerHTML = html;
	return result;
}


/////////////////////////// Results section ////////////////////////////////////

/*
function create_proLpgResult_table(ccname){
	tdata=[];
	
	if(LP_result==undefined){
	LP_result={};
		cname=ccname.length;
		for(i=0;i<cname.length;++i){
			tmp = [cname[i],'Ton'];
			for (j=0;j<12;++j){
				vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
				LP_result[vname]=0;
//				tmp.push(LP_result[vname]);
			}
//			tdata.push(tmp);
		}
		LP_result['obj']=0;
	}

	for(i=0;i<cname.length;++i){
		tmp = [cusExc[cname[i]][0],'Ton'];
		for (j=0;j<12;++j){
			vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
			tmp.push(LP_result[vname].toFixed(2));
		}
		tdata.push(tmp);
	}

	//Total
	tmp_tot=['Total','Ton'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
		tmp += LP_result[vname];
		}
	tmp_tot.push(tmp.toFixed(2));
	}
	tdata.push(tmp_tot);

	//Production
	tmp_prod=['Production','Ton'];
	for(j=0;j<12;++j){
		tmp = prodEst[j];
		tmp_prod.push(tmp.toFixed(2));
	}
	tdata.push(tmp_prod);

	//Inventory
	pre_inv=Number(invConst[3]);
	tmp_inv=['Inventory','Ton'];
	for(j=0;j<12;++j){
		tmp = -Number(tmp_tot[j+2])+Number(tmp_prod[j+2])+pre_inv;
		tmp_inv.push((tmp/den_tpm3).toFixed(2));
		pre_inv = tmp;
	}
	tdata.push(tmp_inv);
//	}

	//Revenue(USD)
	tmp_rev=['Revenue','USD'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(0,i,j);//'c'+(i+1)+(j+1);
		tmp += LP_result[vname]*ccPrice[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(THB)
	tmp_rev=['Revenue','THB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(0,i,j);//'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccPrice[cname[i]][j]*ccExcRate[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);


	var html="<table id=nglResult align = center border=1><tr bgcolor=mediumblue><th>NGL</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if( i<cname.length && j>1){
		html += "<td bgcolor='F9FF7E'>" + numeral(tdata[i][j]).format('0,0') + "</td>";
		}else{
		html += "<td>" + numeral(tdata[i][j]).format('0,0') + "</td>";
		}
	}
	html += "</tr>";
	}		

	html += "</table>"

	document.getElementById("nglResult_table").innerHTML = html;
}
*/

create_maxLim_table(maxLim);
create_nglInput_table(cusNgl);
create_invNgl_table(invNgl);
ccExcRate=create_nglData_table(cusNgl);
ccDemand=create_nglDemand_table(cusNgl);
ccPrice=create_nglPrice_table(cusNgl);
invConst=[invNgl[0]*den_tpm3,invNgl[0]*den_tpm3*invNgl[1]/100,invNgl[0]*den_tpm3*invNgl[2]/100,invNgl[3]*den_tpm3];
extraConst={};
for(i=0;i<cusNgl.length;++i){
	extraConst[cusNgl[i]]=[];
	cc=cusNglData[cusNgl[i]];
	if(cc[5]=="KT/year"){
		extraConst[cusNgl[i]]=[Math.min(cc[6]*1000,maxLim),cc[7]*1000];
	}
	if(cc[5]=="Km3/year"){
		extraConst[cusNgl[i]]=[Math.min(cc[6]*1000*den_tpm3,maxLim),cc[7]*1000*den_tpm3];
	}
}

LP_cmd=create_LP_cmd(cusNgl);
create_nglResult_table(cusNgl);
create_nglRev_table(cusNgl);

//ccExcRate;ccDemand;ccPrice
//prodEst;prodCost;pttExc
//invCosnt;extraConst
LP_cmd=create_LP_cmd(cusNgl);

/*
create_ethRev_table(cusEth);
*/

</script>
</body>
</html>
