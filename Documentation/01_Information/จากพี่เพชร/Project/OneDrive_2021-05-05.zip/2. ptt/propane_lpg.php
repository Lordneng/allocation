<!DOCTYPE html>
<html>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
}
th { color: white; font-size:10pt;}
</style>
<style>
@media print {
    body {-webkit-print-color-adjust: exact;}
    @page {size: A4 ;max-height:100%; max-width:100%;}
    table {page-break-inside: avoid;}
}
</style>

<body>
<script src="glpk.min.js"></script>
<script src="numeral.min.js"></script>
<?php
echo "<script>";
//<script src="basic_data.js"></script>
echo file_get_contents('./basic_data.dat', FILE_USE_INCLUDE_PATH);
echo "</script>";
?>
<script src="conv_data.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<div style="position:relative; top:50px;">
<div align=center><h1>Production Estimation: Propane + LPG</h1></div>
<font size=2>
<button onclick="myFunction()">Print this page</button><br><br>

<script>
function myFunction() {
  window.print();
}
</script>

<font size=4><b>Input:</b></font>&nbsp&nbsp
<input type=button value="Save Input" onclick="update_data()" >
<br><br>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=maxLim_table></div><br><br>
<div id=proInput_table></div><br><br>
<div id=lpgInput_table></div><br><br>
<div id=lpgRefInput_table></div><br><br>
<div id=c3Constraint_table></div><br><br>
<div id=invProLpg_table></div><br><br>
</div>

<h2>Data:</h2>
<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=proLpgData_table></div><br><br>
<div id=proDemand_table></div><br><br>
<div id=lpgDemand_table></div><br><br>
<div id=lpgRefDemand_table></div><br><br>
<div id=proPrice_table></div><br><br>
<div id=lpgPrice_table></div><br><br>
<div id=lpgRefPrice_table></div><br><br>
</div>

<p style="page-break-before: always">
<h2>Results:&nbsp <input type=button value="Calculate" onclick="run()"> 
&nbsp&nbsp<input type=button value="Clear" onclick="clear_result()">
&nbsp&nbsp<input type=button value="Save" onclick="update_data()">
</h2>
<script>
function clear_result() {
	LP_result={};
	create_proLpgResult_table(cusAll)
	create_proLpgRev_table(cusAll); 
}
</script>

<div style="position:relative; overflow:hidden; left:100px;width:1400px;">
<div id=proLpgResult_table></div><br><br>
<div id=proLpgRev_table></div><br><br>
<div id=ethRepTot_table></div><br><br>
</div>
</font>

<div>
<form id="dataForm1" action="./data_write.php" method="post">
	<input type="hidden" name="yy">
	<input type="hidden" name="pCost">
	<input type="hidden" name="rPrice">
	<input type="hidden" name="estVol">
	<input type="hidden" name="maxLim">
	<input type="hidden" name="pttExc">
	<input type="hidden" name="cusName">
	<input type="hidden" name="cusExc">
	<input type="hidden" name="cusEth">
	<input type="hidden" name="cusEthData">
	<input type="hidden" name="cusNgl">
	<input type="hidden" name="cusNglData">
	<input type="hidden" name="invNgl">
	<input type="hidden" name="cusPro">
	<input type="hidden" name="cusLpg">
	<input type="hidden" name="cusLpgRef">
	<input type="hidden" name="cusProData">
	<input type="hidden" name="cusLpgData">
	<input type="hidden" name="cusLpgRefData">
	<input type="hidden" name="invProLpg">
	<input type="hidden" name="c3Constraint">
	<input type="hidden" name="LP_result_eth">
	<input type="hidden" name="LP_result_ngl">
	<input type="hidden" name="LP_result_proLpg">
	<input type="hidden" name="cusEthPrice">
	<input type="hidden" name="cusNglPrice">
	<input type="hidden" name="cusProPrice">
	<input type="hidden" name="cusLpgPrice">
	<input type="hidden" name="cusLpgRefPrice">
	<input type="submit" hidden>
</form>
</div>

<script>
/*
<textarea id="source" cols="50" rows="10"></textarea><br>
*/
</script>
<pre id="log" hidden>
</div>
<script>
var LP_result=LP_result_proLpg;
var start;
var logNode = document.getElementById("log");
var log = glp_print_func = function(value){
    var now = new Date();
        var d = (now.getTime() - start.getTime()) / 1000;
        logNode.appendChild(document.createTextNode(value + "\n"));
    if (d > 60) throw new Error("timeout");
        console.log(value);
};

function run(){
	result={};
	start = new Date(); 
	logNode.innerText = "";
	var lp = glp_create_prob();
	//    glp_read_lp_from_string(lp, null, document.getElementById("source").value);
	glp_read_lp_from_string(lp, null, LP_cmd);

	glp_scale_prob(lp, GLP_SF_AUTO);

	var smcp = new SMCP({presolve: GLP_ON});
	glp_simplex(lp, smcp);

	var iocp = new IOCP({presolve: GLP_ON});
	glp_intopt(lp, iocp);

	log("obj: " + glp_mip_obj_val(lp));
	result["obj"]=glp_mip_obj_val(lp);
	for(var i = 1; i <= glp_get_num_cols(lp); i++){
	log(glp_get_col_name(lp, i)  + " = " + glp_mip_col_val(lp, i));
		result[glp_get_col_name(lp, i)] = glp_mip_col_val(lp, i);
	}
	LP_result=result;
	create_proLpgResult_table(cusAll)
	create_proLpgRev_table(cusAll);
}
</script>

<script>
function arr_diff (a1, a2) {
    var a = [], diff = [];
    for (var i = 0; i < a1.length; i++) {
        a[a1[i]] = true;
    }
    for (var i = 0; i < a2.length; i++) {
        if (a[a2[i]]) {
            delete a[a2[i]];
        } else {
            a[a2[i]] = true;
        }
    }
    for (var k in a) {
        diff.push(k);
    }
    return diff;
}

function update_form(){
	document.getElementsByName("yy")[0].value = var_toString(yy);
	document.getElementsByName("pCost")[0].value = aarray_toString(pCost);
	document.getElementsByName("rPrice")[0].value = aarray_toString(rPrice);
	document.getElementsByName("estVol")[0].value = aarray_toString(estVol);
	document.getElementsByName("maxLim")[0].value = var_toString(maxLim);
	document.getElementsByName("pttExc")[0].value = aarray_toString(pttExc);
	document.getElementsByName("cusName")[0].value = array_toString(cusName);
	document.getElementsByName("cusExc")[0].value = dic_toString(cusExc);
	document.getElementsByName("cusEth")[0].value = array_toString(cusEth);
	document.getElementsByName("cusEthData")[0].value = dic_toString(cusEthData);
	document.getElementsByName("cusNgl")[0].value = array_toString(cusNgl);
	document.getElementsByName("cusNglData")[0].value = dic_toString(cusNglData);
	document.getElementsByName("invNgl")[0].value = array_toString(invNgl);	
	document.getElementsByName("cusPro")[0].value = array_toString(cusPro);
	document.getElementsByName("cusLpg")[0].value = array_toString(cusLpg);
	document.getElementsByName("cusLpgRef")[0].value = array_toString(cusLpgRef);
	document.getElementsByName("cusProData")[0].value = dic_toString(cusProData);
	document.getElementsByName("cusLpgData")[0].value = dic_toString(cusLpgData);
	document.getElementsByName("cusLpgRefData")[0].value = dic_toString(cusLpgRefData);
	document.getElementsByName("invProLpg")[0].value = aarray_toString(invProLpg);	
	document.getElementsByName("c3Constraint")[0].value = aarray_toString(c3Constraint);	
	document.getElementsByName("LP_result_eth")[0].value = dic_toString(LP_result_eth);	
	document.getElementsByName("LP_result_ngl")[0].value = dic_toString(LP_result_ngl);	
	document.getElementsByName("LP_result_proLpg")[0].value = dic_toString(LP_result);	
	document.getElementsByName("cusEthPrice")[0].value = dic_toString(cusEthPrice);	
	document.getElementsByName("cusNglPrice")[0].value = dic_toString(cusNglPrice);	
	document.getElementsByName("cusProPrice")[0].value = dic_toString(ccProPrice);	
	document.getElementsByName("cusLpgPrice")[0].value = dic_toString(ccLpgPrice);	
	document.getElementsByName("cusLpgRefPrice")[0].value = dic_toString(ccLpgRefPrice);	
}

function update_data(){
	get_table_update();
	update_form();
	document.getElementById("dataForm1").submit();
}

function create_maxLim_table(tdata){
	var html="<table id=TmaxLim  border=1><tr>";
	html += "<td bgcolor=mediumblue><font color=white><b>Maximum limit</font></b></td>";
	html += "<td bgcolor='#FF927E' contenteditable='true'>"+tdata+"</td>";
	html += "</tr></table>";
	document.getElementById("maxLim_table").innerHTML = html;
}

function create_proInput_table(cname){
	tdata=[];
	for (i=0;i<cname.length;++i){
		tdata.push([cusExc[cname[i]][0]].concat(cusProData[cname[i]]));
	}
	var html="<table id=proInput  border=1><tr bgcolor=mediumblue><th><font color=yellow>Propane</font></th><th colspan=3>Regulation</th><th colspan=2>Pricing</th><th colspan=3>Extra constr.(Propane)</th></tr>";
	html += "<tr bgcolor=mediumblue><th>Name</th><th>Unit</th><th>Max</th><th>Min</th><th>a</th><th>b</th><th>Unit</th><th>Max</th><th>Min</th><th>Pricing(a)</th><th>add/remove</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2 || j==6 || j==9){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else if(j>6){
		if(tdata[i][6]=="--"){ 
		html += "<td>" + tdata[i][j] +"</td>";		
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "<td align=center><a href='javascript:rem_cus_pro(" + '"' + cname[i] + '"' + ");'>remove</a></td>";
	html += "</tr>";
	}

	diffName = arr_diff(cusName,cname);
	html+= "<tr><td><select id=padd_n>";
	for (i=0;i<diffName.length;++i){
	html += "<option value=" + '"' + diffName[i] + '"' + ">" + cusExc[diffName[i]][0] + "</option>";
	}
	html+= "</select></td>";

	html+= "<td><select id=padd_0>";
/*
	html += '<option value="Km3/month">Km3/month</option>';
	html += '<option value="KT/month">KT/month</option>';
*/
	html += '<option value="Ton/hr">Ton/hr</option>';
	html+= "</select></td>";

	for (i=1;i<5;++i){
	html += "<td id=padd_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=padd_5>";
	html += '<option value="--">--</option>';
	html += '<option value="Ton/year">Ton/year</option>';
	html+= "</select></td>";

	for (i=6;i<8;++i){
	html += "<td id=padd_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=padd_8>";
	html += '<option value="PP">PP</option>';
	html += '<option value="MOP'+"'"+'J">MOP'+"'"+'J</option>';
	html += '<option value="CP+X">CP+X</option>';	
	html+= "</select></td>";

	html += "<td align=center><a href='javascript:add_cus_pro()'>add</a></td>";
	html += "</tr>";
	html += "</table>"
	document.getElementById("proInput_table").innerHTML = html;
}


function rem_cus_pro(cname){
	cc=Object.keys(cusProData);
	var tmp = {};
	for( var i = 0; i < cc.length; i++){ 
	   if ( cc[i] != cname) {
	     tmp[cc[i]]=cusProData[cc[i]]; 
	   }
	}
	cusPro = Object.keys(tmp);
	cusProData = tmp;
	create_proInput_table(cusPro);
}

function add_cus_pro(){
	add_n = document.getElementById("padd_n").value;
	add_0 = document.getElementById("padd_0").value;
	add_1 = document.getElementById("padd_1").innerHTML;
	add_2 = Number(document.getElementById("padd_2").innerHTML);
	add_3 = Number(document.getElementById("padd_3").innerHTML);
	add_4 = Number(document.getElementById("padd_4").innerHTML);
	add_5 = document.getElementById("padd_5").value;
	add_6 = document.getElementById("padd_6").innerHTML;
	add_7 = Number(document.getElementById("padd_7").innerHTML);
	add_8 = document.getElementById("padd_8").value;
	if(add_1!="max"){ 
		add_1 = Number(add_1); 
		if(add_1>maxLim||isNaN(add_1)){add_1=maxLim;}
	}else{add_1=maxLim;}
	if(add_6!="max"){ 
		add_6 = Number(add_6);
		if(add_6>maxLim||isNaN(add_6)){add_6=maxLim;}
	}else{add_6=maxLim;}
	if(add_5=="--"){
		add_6=0; add_7=0;
	}
	cusProData[add_n] = [add_0,add_1,add_2,add_3,add_4,add_5,add_6,add_7,add_8];
	cusPro = Object.keys(cusProData);
	create_proInput_table(cusPro);
}


function create_lpgInput_table(cname){
	tdata=[];
	for (i=0;i<cname.length;++i){
		tdata.push([cusExc[cname[i]][0]].concat(cusLpgData[cname[i]]));
	}
	var html="<table id=lpgInput  border=1><tr bgcolor=mediumblue><th><font color=yellow>LPG</font></th><th colspan=3>Regulation</th><th colspan=2>Pricing</th><th colspan=3>Extra constr.(Propane+LPG)</th></tr>";
	html += "<tr bgcolor=mediumblue><th>Name</th><th>Unit</th><th>Max</th><th>Min</th><th>a</th><th>b</th><th>Unit</th><th>Max</th><th>Min</th><th>Pricing(a)</th><th>add/remove</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2 || j==6||j==9){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else if(j>6){
		if(tdata[i][6]=="--"){ 
		html += "<td>" + tdata[i][j] +"</td>";		
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "<td align=center><a href='javascript:rem_cus_lpg(" + '"' + cname[i] + '"' + ");'>remove</a></td>";
	html += "</tr>";
	}

	diffName = arr_diff(cusName,cname);
	html+= "<tr><td><select id=ladd_n>";
	for (i=0;i<diffName.length;++i){
	html += "<option value=" + '"' + diffName[i] + '"' + ">" + cusExc[diffName[i]][0] + "</option>";
	}
	html+= "</select></td>";

	html+= "<td><select id=ladd_0>";
//	html += '<option value="Km3/month">Km3/month</option>';
	html += '<option value="KT/month">KT/month</option>';
	html += '<option value="Ton/hr">Ton/hr</option>';
	html+= "</select></td>";

	for (i=1;i<5;++i){
	html += "<td id=ladd_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=ladd_5>";
	html += '<option value="--">--</option>';
	html += '<option value="Ton/month">Ton/month</option>';
	html+= "</select></td>";

	for (i=6;i<8;++i){
	html += "<td id=ladd_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=ladd_8>";
	html += '<option value="PP">PP</option>';
	html += '<option value="MOP'+"'"+'J">MOP'+"'"+'J</option>';
	html += '<option value="CP+X">CP+X</option>';	
	html+= "</select></td>";

	html += "<td align=center><a href='javascript:add_cus_lpg()'>add</a></td>";
	html += "</tr>";
	html += "</table>"
	document.getElementById("lpgInput_table").innerHTML = html;
}


function rem_cus_lpg(cname){
	cc=Object.keys(cusLpgData);
	var tmp = {};
	for( var i = 0; i < cc.length; i++){ 
	   if ( cc[i] != cname) {
	     tmp[cc[i]]=cusLpgData[cc[i]]; 
	   }
	}
	cusLpg = Object.keys(tmp);
	cusLpgData = tmp;
	create_lpgInput_table(cusLpg);
}

function add_cus_lpg(){
	add_n = document.getElementById("ladd_n").value;
	add_0 = document.getElementById("ladd_0").value;
	add_1 = document.getElementById("ladd_1").innerHTML;
	add_2 = Number(document.getElementById("ladd_2").innerHTML);
	add_3 = Number(document.getElementById("ladd_3").innerHTML);
	add_4 = Number(document.getElementById("ladd_4").innerHTML);
	add_5 = document.getElementById("ladd_5").value;
	add_6 = document.getElementById("ladd_6").innerHTML;
	add_7 = Number(document.getElementById("ladd_7").innerHTML);
	add_8 = document.getElementById("ladd_8").value;
	if(add_1!="max"){ 
		add_1 = Number(add_1); 
		if(add_1>maxLim||isNaN(add_1)){add_1=maxLim;}
	}else{add_1=maxLim;}
	if(add_6!="max"){ 
		add_6 = Number(add_6);
		if(add_6>maxLim||isNaN(add_6)){add_6=maxLim;}
	}else{add_6=maxLim;}
	if(add_5=="--"){
		add_6=0; add_7=0;
	}
	cusLpgData[add_n] = [add_0,add_1,add_2,add_3,add_4,add_5,add_6,add_7,add_8];
	cusLpg = Object.keys(cusLpgData);
	create_lpgInput_table(cusLpg);
}


function create_lpgRefInput_table(cname){
	tdata=[];
	for (i=0;i<cname.length;++i){
		tdata.push([cusExc[cname[i]][0]].concat(cusLpgRefData[cname[i]]));
	}
	var html="<table id=lpgRefInput  border=1><tr bgcolor=mediumblue><th><font color=yellow>LPG Refinery</font></th><th colspan=3>Regulation</th><th colspan=2>Pricing</th></tr>";
	html += "<tr bgcolor=mediumblue><th>Name</th><th>Unit</th><th>Max</th><th>Min</th><th>a</th><th>b</th><th>Pricing(a)</th><th>add/remove</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2 || j==6){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "<td align=center><a href='javascript:rem_cus_ref(" + '"' + cname[i] + '"' + ");'>remove</a></td>";
	html += "</tr>";
	}

	diffName = arr_diff(cusName,cname);
	html+= "<tr><td><select id=radd_n>";
	for (i=0;i<diffName.length;++i){
	html += "<option value=" + '"' + diffName[i] + '"' + ">" + cusExc[diffName[i]][0] + "</option>";
	}
	html+= "</select></td>";

	html+= "<td><select id=radd_0>";
	html += '<option value="KT/month">KT/month</option>';
	html+= "</select></td>";

	for (i=1;i<5;++i){
	html += "<td id=radd_" + i + " contenteditable='true'>0</td>";
	}

	html+= "<td><select id=radd_5>";
	html += '<option value="PP">PP</option>';
	html += '<option value="MOP'+"'"+'J">MOP'+"'"+'J</option>';
	html += '<option value="CP+X">CP+X</option>';	
	html+= "</select></td>";

	html += "<td align=center><a href='javascript:add_cus_ref()'>add</a></td>";
	html += "</tr>";
	html += "</table>"
	document.getElementById("lpgRefInput_table").innerHTML = html;
}

function rem_cus_ref(cname){
	cc=Object.keys(cusLpgRefData);
	var tmp = {};
	for( var i = 0; i < cc.length; i++){ 
	   if ( cc[i] != cname) {
	     tmp[cc[i]]=cusLpgRefData[cc[i]]; 
	   }
	}
	cusLpgRef = Object.keys(tmp);
	cusLpgRefData = tmp;
	create_lpgRefInput_table(cusLpgRef);
}

function add_cus_ref(){
	add_n = document.getElementById("radd_n").value;
	add_0 = document.getElementById("radd_0").value;
	add_1 = document.getElementById("radd_1").innerHTML;
	add_2 = Number(document.getElementById("radd_2").innerHTML);
	add_3 = Number(document.getElementById("radd_3").innerHTML);
	add_4 = Number(document.getElementById("radd_4").innerHTML);
	add_5 = document.getElementById("radd_5").value;
	if(add_1!="max"){ 
		add_1 = Number(add_1); 
		if(add_1>maxLim||isNaN(add_1)){add_1=maxLim;}
	}else{add_1=maxLim;}
	cusLpgRefData[add_n] = [add_0,add_1,add_2,add_3,add_4,add_5];
	cusLpgRef = Object.keys(cusLpgRefData);
	create_lpgRefInput_table(cusLpgRef);
}


function create_c3Constraint_table(cdata){
	tdata=[['<b>A(Propane+LPG) + B(LPG)</b>'].concat(cdata[0])];
	var html="<table id=Tc3Constraint  border=1><tr bgcolor=mediumblue><th>C3 Constraint</th><th>Unit</th><th>Max</th><th>Min</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("c3Constraint_table").innerHTML = html;
}

function table_data(tname){
	var myTableArray = [];

	$("table#"+tname+" tr").each(function() {
	    var arrayOfThisRow = [];
	    var tableData = $(this).find('td');
	    if (tableData.length > 0) {
		tableData.each(function() { arrayOfThisRow.push($(this).text()); });
		myTableArray.push(arrayOfThisRow);
	    }
	});

	for(i=0;i<myTableArray.length;++i){
		for(j=0;j<myTableArray[i].length;++j){
		if(j>0){
			myTableArray[i][j] = myTableArray[i][j];
		}
		}
	}
	return myTableArray;
}


function create_invProLpg_table(cdata){
	tdata=[['<b>Propane</b>'].concat(cdata[0]),['<b>LPG</b>'].concat(cdata[1])];
	var html="<table id=TinvProLpg  border=1><tr bgcolor=mediumblue><th>Inventory Constraint</th><th>Capacity(Ton)</th><th>Max(%)</th><th>Min(%)</th><th>Current</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j==0){
		html += "<td>" + tdata[i][j] + "</td>";
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("invProLpg_table").innerHTML = html;
}

function table_data(tname){
	var myTableArray = [];

	$("table#"+tname+" tr").each(function() {
	    var arrayOfThisRow = [];
	    var tableData = $(this).find('td');
	    if (tableData.length > 0) {
		tableData.each(function() { arrayOfThisRow.push($(this).text()); });
		myTableArray.push(arrayOfThisRow);
	    }
	});

	for(i=0;i<myTableArray.length;++i){
		for(j=0;j<myTableArray[i].length;++j){
		if(j>0){
			myTableArray[i][j] = myTableArray[i][j];
		}
		}
	}
	return myTableArray;
}

function get_table_update(){
	proInput = table_data("proInput");
	for(i=0;i<cusPro.length;++i){
		for(j=0;j<cusProData[cusPro[i]].length;++j){
			if(j==0||j==5||j==8){
			cusProData[cusPro[i]][j] = proInput[i][j+1];
			} else if(j==1||j==6){
			if(isNaN(Number(proInput[i][j+1]))) {proInput[i][j+1]=maxLim;}
			cusProData[cusPro[i]][j] = Math.min(maxLim,Number(proInput[i][j+1]));
			} else{
			cusProData[cusPro[i]][j] = Number(proInput[i][j+1]);
			}
		}
	}

	lpgInput = table_data("lpgInput");
	for(i=0;i<cusLpg.length;++i){
		for(j=0;j<cusLpgData[cusLpg[i]].length;++j){
			if(j==0||j==5||j==8){
			cusLpgData[cusLpg[i]][j] = lpgInput[i][j+1];
			} else if(j==1||j==6){
			if(isNaN(Number(lpgInput[i][j+1]))) {lpgInput[i][j+1]=maxLim;}
			cusLpgData[cusLpg[i]][j] = Math.min(maxLim,Number(lpgInput[i][j+1]));
			} else{
			cusLpgData[cusLpg[i]][j] = Number(lpgInput[i][j+1]);
			}
		}
	}

	lpgRefInput = table_data("lpgRefInput");
	for(i=0;i<cusLpgRef.length;++i){
		for(j=0;j<cusLpgRefData[cusLpgRef[i]].length;++j){
			if(j==0||j==5){
			cusLpgRefData[cusLpgRef[i]][j] = lpgRefInput[i][j+1];
			} else if(j==1){
			if(isNaN(Number(lpgRefInput[i][j+1]))) {lpgRefInput[i][j+1]=maxLim;}
			cusLpgRefData[cusLpgRef[i]][j] = Math.min(maxLim,Number(lpgRefInput[i][j+1]));
			} else{
			cusLpgRefData[cusLpgRef[i]][j] = Number(lpgRefInput[i][j+1]);
			}
		}
	}
		

	TmaxLim = table_data("TmaxLim");
	tmp_maxLim = Number(TmaxLim[0][1]);
	for(i=0;i<cusNgl.length;++i){
		if(cusNglData[cusNgl[i]][1]==maxLim){
			cusNglData[cusNgl[i]][1]=tmp_maxLim;
		}
		if(cusNglData[cusNgl[i]][6]==maxLim){
			cusNglData[cusNgl[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusPro.length;++i){
		if(cusProData[cusPro[i]][1]==maxLim){
			cusProData[cusPro[i]][1]=tmp_maxLim;
		}
		if(cusProData[cusPro[i]][6]==maxLim){
			cusProData[cusPro[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusLpg.length;++i){
		if(cusLpgData[cusLpg[i]][1]==maxLim){
			cusLpgData[cusLpg[i]][1]=tmp_maxLim;
		}
		if(cusLpgData[cusLpg[i]][6]==maxLim){
			cusLpgData[cusLpg[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusLpgRef.length;++i){
		if(cusLpgRefData[cusLpgRef[i]][1]==maxLim){
			cusLpgRefData[cusLpgRef[i]][1]=tmp_maxLim;
		}
	}
	maxLim = tmp_maxLim;

	TinvProLpg = table_data("TinvProLpg");
	for(i=0;i<2;++i){
		invProLpg[i] = [Number(TinvProLpg[i][1]),Number(TinvProLpg[i][2]),Number(TinvProLpg[i][3]),Number(TinvProLpg[i][4])];
	}

	Tc3data = table_data("Tc3Constraint");
	c3Constraint[0] = [Tc3data[0][1],Number(Tc3data[0][2]),Number(Tc3data[0][3])];
}


/////////////////////////// Data section ////////////////////////////////////


function create_proLpgData_table(cname){
	tdata=[['<b>Estimation Production</b>'].concat(estVol[1])];
	tdata.push([''].concat(estVol[2]));
	tdata.push([''].concat(estVol[4]));
	tmp_d0 = [];tmp_d1 = [];tmp_d2 = [];
	for(i=2;i<estVol[1].length;++i){
		tmp_d0.push(Number((estVol[1][i]*1000).toFixed(3)));
		tmp_d1.push(Number((estVol[2][i]*1000).toFixed(3)));
		tmp_d2.push(Number((estVol[4][i]*1000).toFixed(3)));
	}
	prodEst=[tmp_d0,tmp_d1,tmp_d2];
	prodCost=pCost[3];
//	tdata.push(['','(*1000*'+den_tpm3+')','Ton'].concat(tmp_d));
	tdata.push(['<b>Production Cost</b>'].concat(pCost[1]));
	tdata.push([''].concat(pCost[2]));
	tdata.push([''].concat(pCost[4]));
	tdata.push(['<b>Exchange Rate</b>'].concat(pttExc[0]));
	result={};
	for (i=0;i<cname.length;++i){
		tdata.push([''].concat(cusExc[cname[i]]));
		tmp=[];
		for(j=0;j<12;++j){
			tmp.push(cusExc[cname[i]][j+2]);
		}
		result[cname[i]]=tmp;	
	}
	var html="<table id=proLpgData  border=1><tr bgcolor=mediumblue><th></th><th></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=70>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("proLpgData_table").innerHTML = html;
	return result;
}


function daysInMonth (month, year) {
    return new Date(year, month, 0).getDate();
}

function create_proDemand_table(cname){
	tdata=[];result={};
	for (i=0;i<cname.length;++i){
		maxdata=[cusExc[cname[i]][0],'max','Ton'];
		mindata=['','min','Ton'];
		tmp_max=[];tmp_min=[];
		for (j=0;j<12;++j){
		if(cusProData[cname[i]][0]=="Ton/hr"){
			tmp_max.push(Math.min(24*daysInMonth(j+1,yy)*cusProData[cname[i]][1],maxLim));
			tmp_min.push(24*daysInMonth(j+1,yy)*cusProData[cname[i]][2]);	
		}
		if(cusProData[cname[i]][0]=="KT/month"){
			tmp_max.push(Math.min(cusProData[cname[i]][1]*1000,maxLim));
			tmp_min.push(cusProData[cname[i]][2]*1000);	
		}
		}
		tdata.push(maxdata.concat(tmp_max),mindata.concat(tmp_min));
		result[cname[i]]={"max":tmp_max,"min":tmp_min};
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th colspan=2><font color=yellow>Propane Demand</font></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}	
	
	//Production limit
	html += "<td colspan=2 bgcolor=lightblue><b>Production limit</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	prodLim=[];
	for (j=0;j<12;++j){
		tmp = (estVol[1][j+2]*1000).toFixed(3);
		prodLim.push(Number(tmp));
		html += "<td align=right><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	result["limit"]=prodLim;
	html += "</tr>";

	//Total Max
	html += "<td bgcolor=lightblue><b>Total</b></td><td bgcolor=lightblue><b>max</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_max = 0;
		for (i=0;i<cname.length;++i){
		if(cusProData[cname[i]][0]=="Ton/hr"){
			tmp_max += (Math.min(24*daysInMonth(j+1,yy)*cusProData[cname[i]][1],maxLim));
		}
		if(cusProData[cname[i]][0]=="KT/month"){
			tmp_max += (Math.min(cusProData[cname[i]][1]*1000,maxLim));
		}
		}
		html += "<td align=right><b>"+numeral(tmp_max).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	//Total Min
	html += "<td bgcolor=lightblue></td><td bgcolor=lightblue><b>min</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_min = 0;
		for (i=0;i<cname.length;++i){
		if(cusProData[cname[i]][0]=="Ton/hr"){
			tmp_min += (24*daysInMonth(j+1,yy)*cusProData[cname[i]][2]);	
		}
		if(cusProData[cname[i]][0]=="KT/month"){
			tmp_min += (cusProData[cname[i]][2]*1000);	
		}
		}
		html += "<td align=right><b>"+numeral(tmp_min).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	html += "</table>"

	document.getElementById("proDemand_table").innerHTML = html;
	return result;
}


function create_lpgDemand_table(cname){
	tdata=[];result={};
	for (i=0;i<cname.length;++i){
		maxdata=[cusExc[cname[i]][0],'max','Ton'];
		mindata=['','min','Ton'];
		tmp_max=[];tmp_min=[];
		for (j=0;j<12;++j){
		if(cusLpgData[cname[i]][0]=="Ton/hr"){
			tmp_max.push(Math.min(24*daysInMonth(j+1,yy)*cusLpgData[cname[i]][1],maxLim));
			tmp_min.push(24*daysInMonth(j+1,yy)*cusLpgData[cname[i]][2]);	
		}
		if(cusLpgData[cname[i]][0]=="KT/month"){
			tmp_max.push(Math.min(cusLpgData[cname[i]][1]*1000,maxLim));
			tmp_min.push(cusLpgData[cname[i]][2]*1000);	
		}
		}
		tdata.push(maxdata.concat(tmp_max),mindata.concat(tmp_min));
		result[cname[i]]={"max":tmp_max,"min":tmp_min};
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th colspan=2><font color=yellow>LPG Demand</font></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}	
	
	//Production limit
	html += "<td colspan=2 bgcolor=lightblue><b>Production limit</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	prodLim=[];
	for (j=0;j<12;++j){
		tmp = (estVol[2][j+2]*1000).toFixed(3);
		prodLim.push(Number(tmp));
		html += "<td align=right><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	result["limit"]=prodLim;
	html += "</tr>";

	//Total Max
	html += "<td bgcolor=lightblue><b>Total</b></td><td bgcolor=lightblue><b>max</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_max = 0;
		for (i=0;i<cname.length;++i){
		if(cusLpgData[cname[i]][0]=="Ton/hr"){
			tmp_max += (Math.min(24*daysInMonth(j+1,yy)*cusLpgData[cname[i]][1],maxLim));
		}
		if(cusLpgData[cname[i]][0]=="KT/month"){
			tmp_max += (Math.min(cusLpgData[cname[i]][1]*1000,maxLim));
		}
		}
		html += "<td align=right><b>"+numeral(tmp_max).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	//Total Min
	html += "<td bgcolor=lightblue></td><td bgcolor=lightblue><b>min</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_min = 0;
		for (i=0;i<cname.length;++i){
		if(cusLpgData[cname[i]][0]=="Ton/hr"){
			tmp_min += (24*daysInMonth(j+1,yy)*cusLpgData[cname[i]][2]);	
		}
		if(cusLpgData[cname[i]][0]=="KT/month"){
			tmp_min += (cusLpgData[cname[i]][2]*1000);	
		}
		}
		html += "<td align=right><b>"+numeral(tmp_min).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	html += "</table>"

	document.getElementById("lpgDemand_table").innerHTML = html;
	return result;
}

function create_lpgRefDemand_table(cname){
	tdata=[];result={};
	for (i=0;i<cname.length;++i){
		maxdata=[cusExc[cname[i]][0],'max','Ton'];
		mindata=['','min','Ton'];
		tmp_max=[];tmp_min=[];
		for (j=0;j<12;++j){
		if(cusLpgRefData[cname[i]][0]=="Ton/hr"){
			tmp_max.push(Math.min(24*daysInMonth(j+1,yy)*cusLpgRefData[cname[i]][1],maxLim));
			tmp_min.push(24*daysInMonth(j+1,yy)*cusLpgRefData[cname[i]][2]);	
		}
		if(cusLpgRefData[cname[i]][0]=="KT/month"){
			tmp_max.push(Math.min(cusLpgRefData[cname[i]][1]*1000,maxLim));
			tmp_min.push(cusLpgRefData[cname[i]][2]*1000);	
		}
		}
		tdata.push(maxdata.concat(tmp_max),mindata.concat(tmp_min));
		result[cname[i]]={"max":tmp_max,"min":tmp_min};
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th colspan=2><font color=yellow>LPG Refinery Demand</font></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<3){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			html += "<td align='right' width=80>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}
	}
	html += "</tr>";
	}	
	
	//Production limit
	html += "<td colspan=2 bgcolor=lightblue><b>Production limit</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	prodLim=[];
	for (j=0;j<12;++j){
		tmp = (estVol[4][j+2]*1000).toFixed(3);
		prodLim.push(Number(tmp));
		html += "<td align=right><b>"+numeral(tmp).format('0,0.00')+"</b></td>";
	}
	result["limit"]=prodLim;
	html += "</tr>";

	//Total Max
	html += "<td bgcolor=lightblue><b>Total</b></td><td bgcolor=lightblue><b>max</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_max = 0;
		for (i=0;i<cname.length;++i){
		if(cusLpgRefData[cname[i]][0]=="Ton/hr"){
			tmp_max += (Math.min(24*daysInMonth(j+1,yy)*cusLpgRefData[cname[i]][1],maxLim));
		}
		if(cusLpgRefData[cname[i]][0]=="KT/month"){
			tmp_max += (Math.min(cusLpgRefData[cname[i]][1]*1000,maxLim));
		}
		}
		html += "<td align=right><b>"+numeral(tmp_max).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	//Total Min
	html += "<td bgcolor=lightblue></td><td bgcolor=lightblue><b>min</b></td><td bgcolor=lightblue><b>Ton</b></td>"
	for (j=0;j<12;++j){
		tmp_min = 0;
		for (i=0;i<cname.length;++i){
		if(cusLpgRefData[cname[i]][0]=="Ton/hr"){
			tmp_min += (24*daysInMonth(j+1,yy)*cusLpgRefData[cname[i]][2]);	
		}
		if(cusLpgRefData[cname[i]][0]=="KT/month"){
			tmp_min += (cusLpgRefData[cname[i]][2]*1000);	
		}
		}
		html += "<td align=right><b>"+numeral(tmp_min).format('0,0.00')+"</b></td>";
	}
	html += "</tr>";

	html += "</table>"

	document.getElementById("lpgRefDemand_table").innerHTML = html;
	return result;
}

function create_proPrice_table(cname){
	tdata=[];result={};
	tmp=["PP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[3][i+2]);
	}
	tdata.push(tmp);
	tmp=["MOP'J",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[4][i+3]);
	}
	tdata.push(tmp);
	tmp=["CP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[1][i+3]);
	}
	tdata.push(tmp);
	tmp=["X",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[2][i+3]);
	}
	tdata.push(tmp);

	for (i=0;i<cname.length;++i){
		pdata=[cusExc[cname[i]][0],'$/Ton'];
		tmp=[];
		for (j=0;j<12;++j){

		if(cusProData[cname[i]][8]=="PP"){
		tt = (cusProData[cname[i]][3]*rPrice[3][j+2] + cusProData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		if(cusProData[cname[i]][8]=="MOP'J"){
		tt = (cusProData[cname[i]][3]*rPrice[4][j+3] + cusProData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		if(cusProData[cname[i]][8]=="CP+X"){
		tt = (cusProData[cname[i]][3]*(rPrice[1][j+3]+rPrice[2][j+3]) + cusProData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		}
		tdata.push(pdata.concat(tmp));
		result[cname[i]]=tmp;	
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th><font color=yellow>Propane Pricing</font><br>(a*(var)+b)</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			if(i<4){
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}else{
			html += "<td align='right' bgcolor=#cceeff width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}

		}
	}	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("proPrice_table").innerHTML = html;
	return result;
}

function create_lpgPrice_table(cname){
	tdata=[];result={};
	tmp=["PP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[3][i+2]);
	}
	tdata.push(tmp);
	tmp=["MOP'J",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[4][i+3]);
	}
	tdata.push(tmp);
	tmp=["CP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[1][i+3]);
	}
	tdata.push(tmp);
	tmp=["X",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[2][i+3]);
	}
	tdata.push(tmp);

	for (i=0;i<cname.length;++i){
		pdata=[cusExc[cname[i]][0],'$/Ton'];
		tmp=[];
		for (j=0;j<12;++j){

		if(cusLpgData[cname[i]][8]=="PP"){
		tt = (cusLpgData[cname[i]][3]*rPrice[3][j+2] + cusLpgData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		if(cusLpgData[cname[i]][8]=="MOP'J"){
		tt = (cusLpgData[cname[i]][3]*rPrice[4][j+3] + cusLpgData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		if(cusLpgData[cname[i]][8]=="CP+X"){
		tt = (cusLpgData[cname[i]][3]*(rPrice[1][j+3]+rPrice[2][j+3]) + cusLpgData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		}
		tdata.push(pdata.concat(tmp));
		result[cname[i]]=tmp;	
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th><font color=yellow>LPG Pricing</font><br>(a*(var)+b)</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			if(i<4){
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}else{
			html += "<td align='right' bgcolor=#cceeff width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}

		}
	}	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("lpgPrice_table").innerHTML = html;
	return result;
}

function create_lpgRefPrice_table(cname){
	tdata=[];result={};
	tmp=["PP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[3][i+2]);
	}
	tdata.push(tmp);
	tmp=["MOP'J",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[4][i+3]);
	}
	tdata.push(tmp);
	tmp=["CP",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[1][i+3]);
	}
	tdata.push(tmp);
	tmp=["X",'$/Ton'];
	for (i=0;i<12;++i){
		tmp.push(rPrice[2][i+3]);
	}
	tdata.push(tmp);

	for (i=0;i<cname.length;++i){
		pdata=[cusExc[cname[i]][0],'$/Ton'];
		tmp=[];
		for (j=0;j<12;++j){

		if(cusLpgRefData[cname[i]][5]=="PP"){
		tt = (cusLpgRefData[cname[i]][3]*rPrice[3][j+2] + cusLpgRefData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		if(cusLpgRefData[cname[i]][5]=="MOP'J"){
		tt = (cusLpgRefData[cname[i]][3]*rPrice[4][j+3] + cusLpgRefData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		if(cusLpgRefData[cname[i]][5]=="CP+X"){
		tt = (cusLpgRefData[cname[i]][3]*(rPrice[1][j+3]+rPrice[2][j+3]) + cusLpgRefData[cname[i]][4]);
		tmp.push(Number(tt.toFixed(3)));
		}

		}
		tdata.push(pdata.concat(tmp));
		result[cname[i]]=tmp;	
	}
	var html="<table  border=1><tr bgcolor=mediumblue><th><font color=yellow>LPG Refinery Pricing</font><br>(a*(var)+b)</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
			html += "<td align='right' bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
			if(i<4){
			html += "<td align='right' width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}else{
			html += "<td align='right' bgcolor=#cceeff width=90>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
			}

		}
	}	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("lpgRefPrice_table").innerHTML = html;
	return result;
}


function create_LP_cmd(ccname){
	lp_obj="Maximize\n obj: ";
	for(k=0;k<ccname.length;++k){
	cname = ccname[k];
	for(i=0;i<cname.length;++i){
		for(j=0;j<12;++j){
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			if(k==0){
			lp_obj += ' + ' + (ccProPrice[cname[i]][j]*ccExcRate[cname[i]][j]).toFixed(3) + ' ' + vname;
			}
			if(k==1){
			lp_obj += ' + ' + (ccLpgPrice[cname[i]][j]*ccExcRate[cname[i]][j]).toFixed(3) + ' ' + vname;
			}
			if(k==2){
			lp_obj += ' + ' + (ccLpgRefPrice[cname[i]][j]*ccExcRate[cname[i]][j]).toFixed(3) + ' ' + vname;
			}
		}
	}
	}

	for(j=0;j<12;++j){
	lp_obj += ' + 0 d'+(j+1) + ' + 0 e'+(j+1);
	}

	lp_obj+='\n\n';

	lp_obj+='Subject To\n ';
	
	count=1;

	for(k=2;k<ccname.length;++k){
	cname=ccname[k];

	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		for(i=0;i<cname.length;++i){
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
		if(k==0){
			lp_obj += ' + ' + 'd'+(j+1);
		}

		if(k==1){
			lp_obj += ' - ' + 'd'+(j+1);
			lp_obj += ' - ' + 'e'+(j+1);
		}
		if(k==2){
			lp_obj += ' + ' + 'e'+(j+1);
		}
//		tmp_cond=(prodEst[j] - invConst[0]+invConst[3] - invConst[2]);
//		lp_obj += ' <= ' + Math.min(ccDemand['limit'][j],tmp_cond) + '\n ';
		if(k==0){
		lp_obj += ' <= ' + ccProDemand['limit'][j] + '\n ';
		}
		if(k==1){
		lp_obj += ' <= ' + ccLpgDemand['limit'][j] + '\n ';
		}
		if(k==2){
		lp_obj += ' <= ' + ccLpgRefDemand['limit'][j] + '\n ';
		}
	}
	}


////inventory constraint

//// Propane inventory constraint
	kk=0;	
	cname=ccname[kk];
	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		if(j==0){
		for(i=0;i<cname.length;++i){
			vname = cus_name(kk,i,j);
//			vname = 'c'+(kk+1)+(i+1)+(j+1);
			lp_obj += ' + ' + vname;			
		}
		lp_obj += ' + d1 <= ' + (prodEst[kk][j] + invProConst[3] - invProConst[2]) + '\n ';
		}else{
		for(i=0;i<cname.length;++i){
			for(k=0;k<=j;++k){
			vname = cus_name(kk,i,k);
//			vname = 'c'+(kk+1)+(i+1)+(k+1);
			lp_obj += ' + ' + vname;
			}
		}
		for(k=0;k<=j;++k){
			lp_obj += ' + d'+(k+1); 
		}
		s_proEst=0;
		for(k=0;k<=j;++k){
			s_proEst+=prodEst[kk][k];
		}
		lp_obj += ' <= ' + (s_proEst + invProConst[3] - invProConst[2]) + '\n ';
		}
	}

	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		if(j==0){
		for(i=0;i<cname.length;++i){
			vname = cus_name(kk,i,j);
//			vname = 'c'+(kk+1)+(i+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
		lp_obj += ' + d1 >= ' + (prodEst[kk][j] + invProConst[3] - invProConst[1]) + '\n ';
		}else{
		for(i=0;i<cname.length;++i){
			for(k=0;k<=j;++k){
			vname = cus_name(kk,i,k);
//			vname = 'c'+(kk+1)+(i+1)+(k+1);
			lp_obj += ' + ' + vname;			
			}
		}

		for(k=0;k<=j;++k){
			lp_obj += ' + d'+(k+1); 
		}

		s_proEst=0;
		for(k=0;k<=j;++k){
			s_proEst+=prodEst[kk][k];
		}
		lp_obj += ' >= ' + (s_proEst + invProConst[3] - invProConst[1]) + '\n ';
		}
	}

//// LPG inventory constraint

	kk=1;	
	cname=ccname[kk];
	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		if(j==0){
		for(i=0;i<cname.length;++i){
			vname = cus_name(kk,i,j);
//			vname = 'c'+(kk+1)+(i+1)+(j+1);
			lp_obj += ' + ' + vname;			
		}
/*
		for(k=0;k<ccname[2].length;++k){
			vname = cus_name(2,k,j);
//			vname = 'c'+(3)+(k+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
*/

		lp_obj += ' - e1';

//		lp_obj += ' - d1 <= ' + ( prodEst[2][j] + prodEst[kk][j] + invLpgConst[3] - invLpgConst[2]) + '\n ';
		lp_obj += ' - d1 <= ' + (prodEst[kk][j] + invLpgConst[3] - invLpgConst[2]) + '\n ';
		}else{
		for(i=0;i<cname.length;++i){
			for(k=0;k<=j;++k){
			vname = cus_name(kk,i,k);
//			vname = 'c'+(kk+1)+(i+1)+(k+1);
			lp_obj += ' + ' + vname;
			}
		}

/*
		for(k=0;k<ccname[2].length;++k){
			vname = cus_name(2,k,j);
//			vname = 'c'+(3)+(k+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
*/
//		lp_obj += ' - e' + (j+1);

		for(k=0;k<=j;++k){
			lp_obj += ' - d'+(k+1); 
			lp_obj += ' - e'+(k+1);
		}
		s_proEst=0;
		for(k=0;k<=j;++k){
			s_proEst+=prodEst[kk][k];
		}
//		lp_obj += ' <= ' + (prodEst[2][j] + s_proEst + invLpgConst[3] - invLpgConst[2]) + '\n ';
		lp_obj += ' <= ' + (s_proEst + invLpgConst[3] - invLpgConst[2]) + '\n ';

		}
	}

	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		if(j==0){
		for(i=0;i<cname.length;++i){
			vname = cus_name(kk,i,j);
//			vname = 'c'+(kk+1)+(i+1)+(j+1);
			lp_obj += ' + ' + vname;
		}

/*
		for(k=0;k<ccname[2].length;++k){
			vname = cus_name(2,k,j);
//			vname = 'c'+(3)+(k+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
*/

		lp_obj += ' - e' + (j+1);

//		lp_obj += ' - d1 >= ' + (prodEst[2][j] + prodEst[kk][j] + invLpgConst[3] - invLpgConst[1]) + '\n ';
		lp_obj += ' - d1 >= ' + (prodEst[kk][j] + invLpgConst[3] - invLpgConst[1]) + '\n ';
		}else{
		for(i=0;i<cname.length;++i){
			for(k=0;k<=j;++k){
			vname = cus_name(kk,i,k);
//			vname = 'c'+(kk+1)+(i+1)+(k+1);
			lp_obj += ' + ' + vname;			
			}
		}

/*
		for(k=0;k<ccname[2].length;++k){
			vname = cus_name(2,k,j);
//			vname = 'c'+(3)+(k+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
*/

//		lp_obj += ' - e' + (j+1);

		for(k=0;k<=j;++k){
			lp_obj += ' - d'+(k+1); 
			lp_obj += ' - e'+(k+1);
		}
		s_proEst=0;
		for(k=0;k<=j;++k){
			s_proEst+=prodEst[kk][k];
		}
//		lp_obj += ' >= ' + (prodEst[2][j] + s_proEst + invLpgConst[3] - invLpgConst[1]) + '\n ';
		lp_obj += ' >= ' + (s_proEst + invLpgConst[3] - invLpgConst[1]) + '\n ';
		}
	}

/*
	for(j=0;j<12;++j){
		lp_obj += 's'+(count++)+': ';
		for(k=0;k<ccname[2].length;++k){
			vname = cus_name(2,k,j);
//			vname = 'c'+(3)+(k+1)+(j+1);
			lp_obj += ' + ' + vname;
		}
		lp_obj += ' + e' + (j+1);
		lp_obj += ' = ' + prodEst[2][j] + '\n';
	}	
*/

/////extra constraint

	for(k=0;k<ccname.length-1;++k){
	cname=ccname[k];
	for(i=0;i<cname.length;++i){
	if(k==0){
		if(extraProConst[cname[i]].length>0){
			tmp_obj ="";
			for(j=0;j<12;++j){
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			tmp_obj += ' + ' + vname;
			}
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' <= ' + extraProConst[cname[i]][0] + '\n ';		
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' >= ' + extraProConst[cname[i]][1] + '\n ';	
		}
	}


	if(k==1){
//		if(!(cname[i]=="Customer A" || cname[i]=="Customer B")){
		if(extraLpgConst[cname[i]].length>0){
			for(j=0;j<12;++j){
			tmp_obj ="";
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			tmp_obj += ' + ' + vname;
			vname1= '';
			for(h=0;h<ccname[0].length;++h){
				if(ccname[0][h]==cname[i]){tmp_obj += ' + ' + cus_name(0,h,j);}
//				if(ccname[0][h]==cname[i]){tmp_obj += ' + c'+(1)+(h+1)+(j+1);}
			}
//			if(vname1!='') {tmp_obj += ' + ' + vname1;}

			lp_obj += 's'+(count++)+': ' + tmp_obj + ' <= ' + extraLpgConst[cname[i]][0] + '\n ';		
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' >= ' + extraLpgConst[cname[i]][1] + '\n ';	
			}
		}
//		}
/// C3 Constraint
		if(cname[i]=="Customer A"){
			for(j=0;j<12;++j){
			tmp_obj ="";
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			tmp_obj += ' + ' + vname;
			vname1= '';
			for(h=0;h<ccname[1].length;++h){
				if(ccname[1][h]=="Customer B"){tmp_obj += ' + ' + cus_name(1,h,j);}
//				if(ccname[1][h]=="Customer B"){tmp_obj += ' + c'+(2)+(h+1)+(j+1);}
			}
			for(h=0;h<ccname[0].length;++h){
				if(ccname[0][h]==cname[i]){tmp_obj += ' + ' + cus_name(0,h,j);}
//				if(ccname[0][h]==cname[i]){tmp_obj += ' + c'+(1)+(h+1)+(j+1);}
			}
//			if(vname1!='') {tmp_obj += ' + ' + vname1;}

/*
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' <= ' + extraLpgConst[cname[i]][0] + '\n ';		
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' >= ' + extraLpgConst[cname[i]][1] + '\n ';	
*/
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' <= ' + c3Constraint[0][1] + '\n ';		
			lp_obj += 's'+(count++)+': ' + tmp_obj + ' >= ' + c3Constraint[0][2] + '\n ';	
			}

		}
	}
	}
	}

////end extra constraint

	lp_obj+='\n';
	lp_obj+='Bounds\n ';
	for(k=0;k<ccname.length;++k){
	cname=ccname[k];
	for(i=0;i<cname.length;++i){
		for(j=0;j<12;++j){
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			if(k==0){
			lp_obj += ''+ ccProDemand[cname[i]]['min'][j] + " <= " + vname + " <= " + ccProDemand[cname[i]]['max'][j] + '\n ';
			}
			if(k==1){
			lp_obj += ''+ ccLpgDemand[cname[i]]['min'][j] + " <= " + vname + " <= " + ccLpgDemand[cname[i]]['max'][j] + '\n ';
			}
			if(k==2){
			lp_obj += ''+ ccLpgRefDemand[cname[i]]['min'][j] + " <= " + vname + " <= " + ccLpgRefDemand[cname[i]]['max'][j] + '\n ';
//			lp_obj += ''+ ccLpgRefDemand[cname[i]]['min'][j] + " <= " + vname + " <= " + ccLpgRefDemand[cname[i]]['min'][j] + '\n ';
			}
		}
	}
	}

	for(j=0;j<12;++j){
		lp_obj +=  '0' + " <= " + 'd'+(j+1) + " <= " + ccProDemand['limit'][j] + '\n ';
	}

/*
	for(j=0;j<12;++j){
		lp_obj += '0' + " <= " + 'e'+(j+1) + " <= " + (ccLpgRefDemand['limit'][j] - ccLpgRefDemand['Customer I']['min'][j]) + '\n ';
	}
*/

	lp_obj+='\nEnd\n';

//	document.getElementById("source").value = lp_obj;
	return lp_obj;
}

/////////////////////////// Results section ////////////////////////////////////


function create_proLpgResult_table(ccname){
	tdata=[];
	
	if(LP_result==undefined || Object.keys(LP_result)==0){
	LP_result={};
		for(k=0;k<ccname.length;++k){
		cname=ccname[k];
		for(i=0;i<cname.length;++i){
			tmp = [cname[i],'Ton'];
			for (j=0;j<12;++j){
				vname = cus_name(k,i,j);
//				vname = 'c'+(k+1)+(i+1)+(j+1);
				LP_result[vname]=0;
//				tmp.push(LP_result[vname]);
			}
//			tdata.push(tmp);
		}
		for(j=0;j<12;++j){
			tmp = ['Transfer to LPG','Ton'];	
			vname = 'd'+(j+1);
			LP_result[vname]=0;
			LP_result['e'+(j+1)]=0;
		}
		}
	LP_result['obj']=0;
	}

	for(k=0;k<ccname.length;++k){
	cname=ccname[k];
	if(k==0){
	tdata.push(["<font color=yellow><b>Propane</b></font>","","","","","","","","","","","","",""])
	}
	if(k==1){
	tdata.push(["<font color=yellow><b>LPG</b></font>","","","","","","","","","","","","",""])
	}
	if(k==2){
	tdata.push(["<font color=yellow><b>LPG Refinery</b></font>","","","","","","","","","","","","",""])
	}
	for(i=0;i<cname.length;++i){
		tmp = [cusExc[cname[i]][0],'Ton'];
		for (j=0;j<12;++j){
			vname = cus_name(k,i,j);
//			vname = 'c'+(k+1)+(i+1)+(j+1);
			tmp.push(LP_result[vname].toFixed(2));
		}
		tdata.push(tmp);
	}

	if(k==0){
	tmp = ['Transfer to LPG','Ton'];	
	for(j=0;j<12;++j){
		vname = 'd'+(j+1);
		tmp.push(LP_result[vname].toFixed(2));
	}
		tdata.push(tmp);
	}

	if(k==2){
	tmp = ['Transfer to LPG','Ton'];	
	for(j=0;j<12;++j){
		vname = 'e'+(j+1);
		tmp.push(LP_result[vname].toFixed(2));
	}
		tdata.push(tmp);
	}

	//Total
	tmp_tot=['Total','Ton'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname];
		}
	tmp_tot.push(tmp.toFixed(2));
	}
	tdata.push(tmp_tot);

	//Production
	tmp_prod=['Production','Ton'];
	for(j=0;j<12;++j){
		tmp = prodEst[k][j];
		tmp_prod.push(tmp.toFixed(2));
	}
	tdata.push(tmp_prod);

	if(k==0){
	//Inventory
	pre_inv=Number(invProConst[3]);
	tmp_inv=['Inventory','Ton'];
	for(j=0;j<12;++j){
		tmp = -Number(tmp_tot[j+2])+Number(tmp_prod[j+2])+pre_inv-LP_result['d'+(j+1)];
		tmp_inv.push((tmp).toFixed(2));
		pre_inv = tmp;
	}
	tdata.push(tmp_inv);
	}

	if(k==1){
	//Inventory
	pre_inv=Number(invLpgConst[3]);
	tmp_inv=['Inventory','Ton'];
	for(j=0;j<12;++j){
		tmp = -Number(tmp_tot[j+2])+Number(tmp_prod[j+2])+pre_inv + LP_result['d'+(j+1)] + prodEst[2][j]-LP_result[cus_name(2,0,j)];
//		tmp = -Number(tmp_tot[j+2])+Number(tmp_prod[j+2])+pre_inv + LP_result['d'+(j+1)] + prodEst[2][j]-LP_result['c31'+(j+1)];
		tmp_inv.push((tmp).toFixed(2));
		pre_inv = tmp;
	}
	tdata.push(tmp_inv);
	}

	if(k==0){
	//Revenue(USD)
	tmp_rev=['Revenue','$'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccProPrice[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(THB)
	tmp_rev=['Revenue','THB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccProPrice[cname[i]][j]*ccExcRate[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(MB)
	tmp_rev=['Revenue','MB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccProPrice[cname[i]][j]*ccExcRate[cname[i]][j]/1000000;
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);
	}//end k=0

	if(k==1){
	//Revenue(USD)
	tmp_rev=['Revenue','$'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccLpgPrice[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(THB)
	tmp_rev=['Revenue','THB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccLpgPrice[cname[i]][j]*ccExcRate[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(MB)
	tmp_rev=['Revenue','MB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccLpgPrice[cname[i]][j]*ccExcRate[cname[i]][j]/1000000;
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	}//end k=1

	if(k==2){
	//Revenue(USD)
	tmp_rev=['Revenue','$'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccLpgRefPrice[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(THB)
	tmp_rev=['Revenue','THB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccLpgRefPrice[cname[i]][j]*ccExcRate[cname[i]][j];
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	//Revenue(MB)
	tmp_rev=['Revenue','MB'];
	for(j=0;j<12;++j){
		tmp = 0;
		for(i=0;i<cname.length;++i){
		vname = cus_name(k,i,j);
//		vname = 'c'+(k+1)+(i+1)+(j+1);
		tmp += LP_result[vname]*ccLpgRefPrice[cname[i]][j]*ccExcRate[cname[i]][j]/1000000;
		}
	tmp_rev.push(tmp.toFixed(2));
	}
	tdata.push(tmp_rev);

	}//end k=2

	}//end k

	var html="<table id=proLpgResult  border=1><tr bgcolor=mediumblue><th></th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	html += "<tr>"
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){

	if( tdata[i][0]!=="Total" && tdata[i][0]!=="Production" && tdata[i][0]!=="Inventory" && tdata[i][0]!=="Revenue" && tdata[i][0]!=="<font color=yellow><b>Propane</b></font>" && tdata[i][0]!=="<font color=yellow><b>LPG</b></font>" && tdata[i][0]!=="<font color=yellow><b>LPG Refinery</b></font>"){
		if(j<2){
		html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
		if(tdata[i][j]!==''){
		html += "<td bgcolor='F9FF7E' align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}else{html+= "<td></td>";}
		}
	}else{
		if(j<2){
		html += "<td bgcolor=lightblue>" + tdata[i][j] + "</td>";
		}else{
		if(tdata[i][j]!==''){
		html += "<td align=right>" + numeral(tdata[i][j]).format('0,0.00') + "</td>";
		}else{html+= "<td></td>";}
		}		
	}
	}
	html += "</tr>";
	}		

	html += "</table>"

	document.getElementById("proLpgResult_table").innerHTML = html;
}

function create_proLpgRev_table(cname){
	tdata=[];result={};
	tmp_data = table_data("proLpgData");
	var marg=0;
	var prod_all=0;
	tdata.push(["<b>Revenue(THB)</b>",LP_result['obj']]);
	for(k=0;k<3;++k){
	prod=0;
	for (i=0;i<12;++i){
		prod += Number(tmp_data[0+k][i+3])*Number(tmp_data[3+k][i+3])*Number(tmp_data[6][i+3]);
	}

	prod = 1000.0*prod;
	prod_all+=prod;
	if(k==0){
		tdata.push(["Propane Production(THB)",prod]);
	}
	if(k==1){
		tdata.push(["LPG Production(THB)",prod]);	
	}
	if(k==2){
		tdata.push(["LPG Refinery Production(THB)",prod]);	
	}

	}
	marg = LP_result['obj']-prod_all;
	tdata.push(["<b>Total Production(THB)</b>",prod_all]);
	tdata.push(["<b>Margin(THB)</b>",marg]);

	var html="<table  border=1>";
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	html += "<td bgcolor=mediumblue><font color=white>" + tdata[i][0] + "</font></td>";
	html += "<td align=right width=120>" + numeral(tdata[i][1]).format('0,0') + "</td>";
	html += "</tr>";
	}		
	html += "</table>"

	document.getElementById("proLpgRev_table").innerHTML = html;
//	return result;
}


create_maxLim_table(maxLim);
create_proInput_table(cusPro);
create_lpgInput_table(cusLpg);
create_lpgRefInput_table(cusLpgRef);
create_c3Constraint_table(c3Constraint);
create_invProLpg_table(invProLpg);

tmp_cus = {};
for(i=0;i<cusPro.length;++i){
	tmp_cus[cusPro[i]]=[];
}
for(i=0;i<cusLpg.length;++i){
	tmp_cus[cusLpg[i]]=[];
}
for(i=0;i<cusLpgRef.length;++i){
	tmp_cus[cusLpgRef[i]]=[];
}

ccExcRate=create_proLpgData_table(Object.keys(tmp_cus).sort());
ccProDemand=create_proDemand_table(cusPro);
ccLpgDemand=create_lpgDemand_table(cusLpg);
ccLpgRefDemand=create_lpgRefDemand_table(cusLpgRef);

ccProPrice=create_proPrice_table(cusPro);
ccLpgPrice=create_lpgPrice_table(cusLpg);
ccLpgRefPrice=create_lpgRefPrice_table(cusLpgRef);

invPro=invProLpg[0];
invLpg=invProLpg[1];
invProConst=[invPro[0],invPro[0]*invPro[1]/100,invPro[0]*invPro[2]/100,invPro[3]];
invLpgConst=[invLpg[0],invLpg[0]*invLpg[1]/100,invLpg[0]*invLpg[2]/100,invLpg[3]];

extraProConst={};
for(i=0;i<cusPro.length;++i){
	extraProConst[cusPro[i]]=[];
	cc=cusProData[cusPro[i]];
	if(cc[5]=="Ton/year"){
	extraProConst[cusPro[i]]=[cc[6],cc[7]];
	}
}

extraLpgConst={};
for(i=0;i<cusLpg.length;++i){
	extraLpgConst[cusLpg[i]]=[];
	cc=cusLpgData[cusLpg[i]];
	if(cc[5]=="Ton/month"){
	extraLpgConst[cusLpg[i]]=[cc[6],cc[7]];
	}
}

cusAll=[cusPro,cusLpg,cusLpgRef];
LP_cmd=create_LP_cmd(cusAll);
create_proLpgResult_table(cusAll);
create_proLpgRev_table(cusAll);
//ccExcRate;ccDemand;ccPrice
//prodEst;prodCost;pttExc
//invCosnt;extraConst
//LP_cmd=create_LP_cmd(cusNgl);

/*
create_ethRev_table(cusEth);
*/

</script>
</body>
</html>
