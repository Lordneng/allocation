<!DOCTYPE html>
<html>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<head>
<script>
function LoadPage(){
document.getElementsByName('f_menu')[0].src='menu.php';
<?php 	 
	if(file_exists($_GET["id"].".php")){
	echo "document.getElementsByName('f_main')[0].src='" . $_GET["id"] . ".php';";
	}
	else {
	echo "document.getElementsByName('f_main')[0].src='basic_data_jexcel.php';";
	}
?>	
};
</script>
</head>
<frameset cols="250px,*" frameborder=no framespacing=0 border=0 onload="LoadPage();"> 
<frame name="f_menu" > 
<frame name="f_main" > 
</frameset>
</html>
