<!DOCTYPE html>
<html>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  border: 1px solid black;
}
</style>
<style>
@media print {
    body {-webkit-print-color-adjust: exact;}
    @page {size: A4 ;max-height:100%; max-width:100%}
    table {page-break-inside: avoid;}
}
</style>
<body>
<?php
echo "<script>";
//<script src="basic_data.js"></script>
echo file_get_contents('./basic_data.dat', FILE_USE_INCLUDE_PATH);
echo "</script>";
?>
<script src="conv_data.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<script src="numeral.min.js"></script>
<script src="excel-formula.min.js"></script>
<script src="jquery.jexcel.js"></script>
<link rel="stylesheet" href="jquery.jexcel.css" type="text/css" />

<div style="position:relative; top:50px;">
<div align=center>
<font size=6><b>Basic Data</b></font>
</div><br>
<font size=2>
<button onclick="myFunction()">Print this page</button><br><br>
<script>
function myFunction() {
  window.print();
}
</script>

<font size=4><b>Input:</b></font>&nbsp&nbsp
<input type=button value="Save Data" onclick="update_data()" ><br><br>

<div style="position:relative; overflow:hidden; left:100px;width:1100px;height:200px;">
<div id=pc_table style="position:absolute; left:-30px;"></div>
</div>

<div style="position:relative; overflow:hidden; left:100px;width:1100px;height:230px;">
<div id=rp_table style="position:absolute; left:-30px;"></div>
</div>

<div style="position:relative; overflow:hidden; left:100px;width:1100px;height:200px;">
<div id=estVol_table style="position:absolute; left:-30px;"></div>
</div>

<div style="position:relative; overflow:hidden; left:100px;width:1100px;height:100px;">
<div id=maxLim_table style="position:absolute; left:-30px;"></div>
</div>

<div style="position:relative; overflow:hidden; left:100px;width:1100px;height:100px;">
<div id=pttExc_table style="position:absolute; left:-30px;"></div>
</div>

<div style="position:relative; overflow:hidden; left:100px;width:1100px;height:500px;">
<div id=cusExc_table style="position:absolute; left:-30px;"></div>
</div>

<!--
<div id=pc_table></div><br><br>
<div id=rp_table></div><br><br>
<div id=estVol_table></div><br><br>
<div id=maxLim_table style="position:relative; left:100px;width:1100px;height:100px"></div><br><br>
<div id=pttExc_table></div><br><br>
<div id=cusExc_table></div><br><br>
-->

</font>
<div>
<form id="dataForm" action="./data_write.php" method="post">
	<input type="hidden" name="yy">
	<input type="hidden" name="pCost">
	<input type="hidden" name="rPrice">
	<input type="hidden" name="estVol">
	<input type="hidden" name="maxLim">
	<input type="hidden" name="pttExc">
	<input type="hidden" name="cusName">
	<input type="hidden" name="cusExc">
	<input type="hidden" name="cusEth">
	<input type="hidden" name="cusEthData">
	<input type="hidden" name="cusNgl">
	<input type="hidden" name="cusNglData">
	<input type="hidden" name="invNgl">
	<input type="hidden" name="cusPro">
	<input type="hidden" name="cusLpg">
	<input type="hidden" name="cusLpgRef">
	<input type="hidden" name="cusProData">
	<input type="hidden" name="cusLpgData">
	<input type="hidden" name="cusLpgRefData">
	<input type="hidden" name="invProLpg">
	<input type="hidden" name="c3Constraint">
	<input type="hidden" name="LP_result_eth">
	<input type="hidden" name="LP_result_ngl">
	<input type="hidden" name="LP_result_proLpg">
	<input type="hidden" name="cusEthPrice">
	<input type="hidden" name="cusNglPrice">
	<input type="hidden" name="cusProPrice">
	<input type="hidden" name="cusLpgPrice">
	<input type="hidden" name="cusLpgRefPrice">
	<input type="submit" hidden>
</form>
</div>
</div>
<script>

function create_pc_table(tdata){
//	var html="<table id=TpCost align = center border=1><tr bgcolor=lightblue><th>Production Cost</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";

$('#pc_table').jexcel({
    data:tdata,
    allowInsertRow:false,
    allowInsertColumn:false,
    allowDeleteRow:false,
    allowDeleteColumn:false,
    columnSorting:false,
    columns: [
        { type:'text' },
	{ type:'text' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
    ],
    colHeaders: ['Production Cost','Unit','Jan-19','Feb-19','Mar-19','Apr-19','May-19','Jun-19','Jul-19','Aug-19','Sep-19','Oct-19','Nov-19','Dec-19'],
    colWidths: [ 150, 50, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65]
});

$('#pc_table').jexcel('updateSettings', {
    table: function (instance, cell, col, row, val, id) {
	if (col==0||col==1){
		$(cell).addClass('readonly');
	        $(cell).css('font-weight', 'bold');
	        $(cell).css('color', 'black');
		$(cell).css('background-color','lightblue');
	}
      // Format numbers
	if(col>1){
            // Get text
            txt = $(cell).text();
            // Format text
            txt = numeral(txt).format('0,0.00');
            // Update cell value
            $(cell).html('<input type="hidden" value="' + val + '">' + txt);
            $(cell).css('background-color', '#FF927E');
            $(cell).css('text-align', 'right');
        }
    }
});

/*
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("pc_table").innerHTML = html;
*/
}


function create_rp_table(tdata){
$('#rp_table').jexcel({
    data:tdata,
    allowInsertRow:false,
    allowInsertColumn:false,
    allowDeleteRow:false,
    allowDeleteColumn:false,
    columnSorting:false,
    columns: [
        { type:'text' },
	{ type:'text' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
    ],
    colHeaders: ['Reference Price','Unit','Dec-18','Jan-19','Feb-19','Mar-19','Apr-19','May-19','Jun-19','Jul-19','Aug-19','Sep-19','Oct-19','Nov-19','Dec-19'],
    colWidths: [ 150, 50, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65]
});

$('#rp_table').jexcel('updateSettings', {
    table: function (instance, cell, col, row, val, id) {
	if (col==0||col==1){
		$(cell).addClass('readonly');
	        $(cell).css('font-weight', 'bold');
	        $(cell).css('color', 'black');
		$(cell).css('background-color','lightblue');
	}
      // Format numbers
	if(col>1){
            // Get text
            txt = $(cell).text();
            // Format text
            txt = numeral(txt).format('0,0.00');
            // Update cell value
            $(cell).html('<input type="hidden" value="' + val + '">' + txt);
            $(cell).css('background-color', '#FF927E');
            $(cell).css('text-align', 'right');
        }
    }
});
/*
	var html="<table id=TrPrice align = center border=1><tr bgcolor=lightblue><th>Reference Price</th><th>Unit</th><th>Dec-18</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("rp_table").innerHTML = html;
*/
}

function create_estVol_table(tdata){
$('#estVol_table').jexcel({
    data:tdata,
    allowInsertRow:false,
    allowInsertColumn:false,
    allowDeleteRow:false,
    allowDeleteColumn:false,
    columnSorting:false,
    columns: [
        { type:'text' },
	{ type:'text' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
    ],
    colHeaders: ['Estimated Volume','Unit','Jan-19','Feb-19','Mar-19','Apr-19','May-19','Jun-19','Jul-19','Aug-19','Sep-19','Oct-19','Nov-19','Dec-19'],
    colWidths: [ 150, 50, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65]
});

$('#estVol_table').jexcel('updateSettings', {
    table: function (instance, cell, col, row, val, id) {	
	if (col==0||col==1){
		$(cell).addClass('readonly');
	        $(cell).css('font-weight', 'bold');
	        $(cell).css('color', 'black');
		$(cell).css('background-color','lightblue');
	}
      // Format numbers
	if(col>1){
            // Get text
            txt = $(cell).text();
            // Format text
            txt = numeral(txt).format('0,0.00');
            // Update cell value
            $(cell).html('<input type="hidden" value="' + val + '">' + txt);
            $(cell).css('background-color', '#FF927E');
            $(cell).css('text-align', 'right');
        }
    }

});
/*
	var html="<table id=TestVol align = center border=1><tr bgcolor=lightblue><th>Estimated volume</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	for (i=0;i<tdata.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("estVol_table").innerHTML = html;
*/
}

function create_maxLim_table(tdata){
ttdata=[["Maximum Limit",tdata]];
$('#maxLim_table').jexcel({
    data:ttdata,
    allowInsertRow:false,
    allowInsertColumn:false,
    allowDeleteRow:false,
    allowDeleteColumn:false,
    columnSorting:false,
    columns: [
        { type:'text' },
        { type:'numeric' },
    ],
    colHeaders: [' ','Unit(Ton)'],
    colWidths: [ 150, 100]
});

$('#maxLim_table').jexcel('updateSettings', {
    table: function (instance, cell, col, row, val, id) {	
	if (col==0){
		$(cell).addClass('readonly');
	        $(cell).css('font-weight', 'bold');
	        $(cell).css('color', 'black');
		$(cell).css('background-color','lightblue');
	}
      // Format numbers
	if(col>0){
            // Get text
            txt = $(cell).text();
            // Format text
            txt = numeral(txt).format('0,0');
            // Update cell value
            $(cell).html('<input type="hidden" value="' + val + '">' + txt);
            $(cell).css('background-color', '#FF927E');
            $(cell).css('text-align', 'right');
        }
    }
});
/*

	var html="<table id=TmaxLim align=left border=1><tr>";
	html += "<td bgcolor=lightgray width=150px><b>Maximum limit</b></td>";
	html += "<td bgcolor='#FF927E' contenteditable='true'>"+tdata+"</td>";
	html += "</tr></table>";
	document.getElementById("maxLim_table").innerHTML = html;
*/
}

function create_pttExc_table(tdata){
$('#pttExc_table').jexcel({
    data:tdata,
    allowInsertRow:false,
    allowInsertColumn:false,
    allowDeleteRow:false,
    allowDeleteColumn:false,
    columnSorting:false,
    columns: [
        { type:'text' },
	{ type:'text' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
    ],
    colHeaders: ['Exchange Rate','Unit','Jan-19','Feb-19','Mar-19','Apr-19','May-19','Jun-19','Jul-19','Aug-19','Sep-19','Oct-19','Nov-19','Dec-19'],
    colWidths: [ 130, 70, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65]
});

$('#pttExc_table').jexcel('updateSettings', {
    table: function (instance, cell, col, row, val, id) {	
	if (col==0||col==1){
		$(cell).addClass('readonly');
	        $(cell).css('font-weight', 'bold');
	        $(cell).css('color', 'black');
		$(cell).css('background-color','lightblue');
	}
      // Format numbers
	if(col>1){
            // Get text
            txt = $(cell).text();
            // Format text
            txt = numeral(txt).format('0,0.00');
            // Update cell value
            $(cell).html('<input type="hidden" value="' + val + '">' + txt);
            $(cell).css('background-color', '#FF927E');
            $(cell).css('text-align', 'right');
        }
    }

});
/*
	var html="<table id=TpttExc align = center border=1><tr bgcolor=lightgray><th>Exchange rate</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	for (i=0;i<tdata.length;++i){
	html += "<tr>"
	for (j=0;j<tdata[i].length;++j){
		if(j<2){
		html += "<td><b>" + tdata[i][j] + "</b></td>";
		} else {
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[i][j] + "</td>";
		}	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("pttExc_table").innerHTML = html;
*/
}

function create_cusExc_table(cname,tdata){
ttdata=[];
for (i=0;i<cname.length;++i){
	ttdata.push(tdata[cname[i]]);
}

$('#cusExc_table').jexcel({
    data:ttdata,
    allowInsertRow:false,
    allowInsertColumn:false,
    allowDeleteRow:false,
    allowDeleteColumn:false,
    columnSorting:false,
    columns: [
        { type:'text' },
	{ type:'text' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
        { type:'numeric' },
    ],
    colHeaders: ['Exchange Rate','Unit','Jan-19','Feb-19','Mar-19','Apr-19','May-19','Jun-19','Jul-19','Aug-19','Sep-19','Oct-19','Nov-19','Dec-19'],
    colWidths: [ 130, 70, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65]
});

$('#cusExc_table').jexcel('updateSettings', {
    table: function (instance, cell, col, row, val, id) {	
	if(col==0){
            $(cell).css('background-color', '#FF927E');
	    $(cell).css('font-weight', 'bold');
//            $(cell).css('text-align', 'left');
        }
	if (col==1){
		$(cell).addClass('readonly');
	        $(cell).css('font-weight', 'bold');
	        $(cell).css('color', 'black');
		$(cell).css('background-color','lightblue');
	}
      // Format numbers
	if(col>1){
            // Get text
            txt = $(cell).text();
            // Format text
            txt = numeral(txt).format('0,0.00');
            // Update cell value
            $(cell).html('<input type="hidden" value="' + val + '">' + txt);
            $(cell).css('background-color', '#FF927E');
            $(cell).css('text-align', 'right');
        }
    }

});
/*
	var html="<table id=TcusExc align = center border=1><tr bgcolor=lightgray><th>Customer Name</th><th>Unit</th><th>Jan-19</th><th>Feb-19</th><th>Mar-19</th><th>Apr-19</th><th>May-19</th><th>Jun-19</th><th>Jul-19</th><th>Aug-19</th><th>Sep-19</th><th>Oct-19</th><th>Nov-19</th><th>Dec-19</th></tr>";
	for (i=0;i<cname.length;++i){
	html += "<tr>";
	for (j=0;j<tdata[cname[i]].length;++j){
		if(j==1){
		html += "<td><b>" + tdata[cname[i]][j] + "</b></td>";
		}else{
		html += "<td bgcolor='#FF927E' contenteditable='true'>" + tdata[cname[i]][j] + "</td>";
		}
	}
	html += "</tr>";
	}
	html += "</table>"
	document.getElementById("cusExc_table").innerHTML = html;
*/
}

function update_form(){
	document.getElementsByName("yy")[0].value = var_toString(yy);
	document.getElementsByName("pCost")[0].value = aarray_toString(pCost);
	document.getElementsByName("rPrice")[0].value = aarray_toString(rPrice);
	document.getElementsByName("estVol")[0].value = aarray_toString(estVol);
	document.getElementsByName("maxLim")[0].value = var_toString(maxLim);
	document.getElementsByName("pttExc")[0].value = aarray_toString(pttExc);
	document.getElementsByName("cusName")[0].value = array_toString(cusName);
	document.getElementsByName("cusExc")[0].value = dic_toString(cusExc);
	document.getElementsByName("cusEth")[0].value = array_toString(cusEth);
	document.getElementsByName("cusEthData")[0].value = dic_toString(cusEthData);
	document.getElementsByName("cusNgl")[0].value = array_toString(cusNgl);
	document.getElementsByName("cusNglData")[0].value = dic_toString(cusNglData);
	document.getElementsByName("invNgl")[0].value = array_toString(invNgl);	
	document.getElementsByName("cusPro")[0].value = array_toString(cusPro);
	document.getElementsByName("cusLpg")[0].value = array_toString(cusLpg);
	document.getElementsByName("cusLpgRef")[0].value = array_toString(cusLpgRef);
	document.getElementsByName("cusProData")[0].value = dic_toString(cusProData);
	document.getElementsByName("cusLpgData")[0].value = dic_toString(cusLpgData);
	document.getElementsByName("cusLpgRefData")[0].value = dic_toString(cusLpgRefData);
	document.getElementsByName("invProLpg")[0].value = aarray_toString(invProLpg);	
	document.getElementsByName("c3Constraint")[0].value = aarray_toString(c3Constraint);	
	document.getElementsByName("LP_result_eth")[0].value = dic_toString(LP_result_eth);	
	document.getElementsByName("LP_result_ngl")[0].value = dic_toString(LP_result_ngl);	
	document.getElementsByName("LP_result_proLpg")[0].value = dic_toString(LP_result_proLpg);
	document.getElementsByName("cusEthPrice")[0].value = dic_toString(cusEthPrice);	
	document.getElementsByName("cusNglPrice")[0].value = dic_toString(cusNglPrice);	
	document.getElementsByName("cusProPrice")[0].value = dic_toString(cusProPrice);	
	document.getElementsByName("cusLpgPrice")[0].value = dic_toString(cusLpgPrice);	
	document.getElementsByName("cusLpgRefPrice")[0].value = dic_toString(cusLpgRefPrice);
}

function update_data(){
	get_table_update();
	update_form();
	document.getElementById("dataForm").submit();
}

function table_data(tname){
	var myTableArray = [];

	$("table#"+tname+" tr").each(function() {
	    var arrayOfThisRow = [];
	    var tableData = $(this).find('td');
	    if (tableData.length > 0) {
		tableData.each(function() { arrayOfThisRow.push($(this).text()); });
		myTableArray.push(arrayOfThisRow);
	    }
	});

	for(i=0;i<myTableArray.length;++i){
		for(j=0;j<myTableArray[i].length;++j){
		if(j>1){
			myTableArray[i][j] = Number(myTableArray[i][j]);
		}
		}
	}
	return myTableArray;
}

function get_table_update(){
/*
<div id=pc_table></div><br><br>
<div id=rp_table></div><br><br>
<div id=estVol_table></div><br><br>
<div id=maxLim_table style="position:relative; left:100px;width:1100px;height:100px"></div><br><br>
<div id=pttExc_table></div><br><br>
<div id=cusExc_table></div><br><br>
*/
//	pCost = table_data("TpCost");
	pCost = $('#pc_table').jexcel('getData');
	for(i=0;i<pCost.length;++i){
		for(j=2;j<pCost[i].length;++j){
			pCost[i][j]=Number(pCost[i][j]);
		}
	}

//	rPrice = table_data("TrPrice");
	rPrice = $('#rp_table').jexcel('getData');
	for(i=0;i<rPrice.length;++i){
		for(j=2;j<rPrice[i].length;++j){
			rPrice[i][j]=Number(rPrice[i][j]);
		}
	}


//	estVol = table_data("TestVol"); 
	estVol = $('#estVol_table').jexcel('getData');
	for(i=0;i<estVol.length;++i){
		for(j=2;j<estVol[i].length;++j){
			estVol[i][j]=Number(estVol[i][j]);
		}
	}

	
//	TmaxLim = table_data("TmaxLim");
	TmaxLim = $('#maxLim_table').jexcel('getData');
	tmp_maxLim = Number(TmaxLim[0][1]);
	for(i=0;i<cusNgl.length;++i){
		if(cusNglData[cusNgl[i]][1]==maxLim){
			cusNglData[cusNgl[i]][1]=tmp_maxLim;
		}
		if(cusNglData[cusNgl[i]][6]==maxLim){
			cusNglData[cusNgl[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusPro.length;++i){
		if(cusProData[cusPro[i]][1]==maxLim){
			cusProData[cusPro[i]][1]=tmp_maxLim;
		}
		if(cusProData[cusPro[i]][6]==maxLim){
			cusProData[cusPro[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusLpg.length;++i){
		if(cusLpgData[cusLpg[i]][1]==maxLim){
			cusLpgData[cusLpg[i]][1]=tmp_maxLim;
		}
		if(cusLpgData[cusLpg[i]][6]==maxLim){
			cusLpgData[cusLpg[i]][6]=tmp_maxLim;
		}
	}
	for(i=0;i<cusLpgRef.length;++i){
		if(cusLpgRefData[cusLpgRef[i]][1]==maxLim){
			cusLpgRefData[cusLpgRef[i]][1]=tmp_maxLim;
		}
	}
	maxLim = tmp_maxLim;

//	pttExc = table_data("TpttExc");
	pttExc = $('#pttExc_table').jexcel('getData');
	for(i=0;i<pttExc.length;++i){
		for(j=2;j<pttExc[i].length;++j){
			pttExc[i][j]=Number(pttExc[i][j]);
		}
	}


//	TcusExc = table_data("TcusExc");
	TcusExc = $('#cusExc_table').jexcel('getData');
	var cc=Object.keys(cusExc);
	for(i=0;i<cc.length;++i){
		cusExc[cc[i]]=TcusExc[i];
		for(j=2;j<cusExc[cc[i]].length;++j){
			cusExc[cc[i]][j]=Number(cusExc[cc[i]][j]);
		}
	}
}

create_pc_table(pCost);
create_rp_table(rPrice);
create_estVol_table(estVol);
create_maxLim_table(maxLim);
create_pttExc_table(pttExc);
create_cusExc_table(cusName,cusExc);

</script>
</body>
</html>
